package dev.vellum.mod.client;

import com.mojang.blaze3d.platform.InputConstants;
import dev.vellum.engine.event.Modifiers;
import net.minecraft.client.input.KeyEvent;
import org.jspecify.annotations.Nullable;
import org.lwjgl.sdl.SDLKeyboard;
import org.lwjgl.sdl.SDLScancode;

/**
 * Minecraft's input to DOM names, on 26.x (SDL). {@code code} comes from the scancode (the physical key:
 * {@code KeyA}, {@code Digit1}, {@code ArrowLeft}); {@code key} from the keycode (the layout's character: {@code a},
 * {@code A} with shift, {@code Enter}, {@code Escape}). Each Minecraft version has its own KeyNames.
 */
final class KeyNames {
    private KeyNames() {}

    /** The DOM {@code code} of a key event: the physical key. */
    static String code(KeyEvent e) {
        return code(e.key());
    }

    /** The DOM {@code key} of a key event: what the key means on the current layout, with shift. */
    static String key(KeyEvent e) {
        return key(e.key(), e.keycode(), e.hasShiftDown());
    }

    static String code(int scancode) {
        if (scancode >= InputConstants.KEY_A && scancode <= InputConstants.KEY_Z) return "Key" + (char) ('A' + scancode - InputConstants.KEY_A);
        if (scancode >= InputConstants.KEY_1 && scancode <= InputConstants.KEY_9) return "Digit" + (scancode - InputConstants.KEY_1 + 1);
        if (scancode >= InputConstants.KEY_F1 && scancode <= InputConstants.KEY_F12) return "F" + (scancode - InputConstants.KEY_F1 + 1);
        return switch (scancode) {
            case InputConstants.KEY_0 -> "Digit0";
            case InputConstants.KEY_RETURN -> "Enter";
            case InputConstants.KEY_NUMPADENTER -> "NumpadEnter";
            case InputConstants.KEY_ESCAPE -> "Escape";
            case InputConstants.KEY_BACKSPACE -> "Backspace";
            case InputConstants.KEY_TAB -> "Tab";
            case InputConstants.KEY_SPACE -> "Space";
            case InputConstants.KEY_MINUS -> "Minus";
            case InputConstants.KEY_EQUALS -> "Equal";
            case InputConstants.KEY_LBRACKET -> "BracketLeft";
            case InputConstants.KEY_RBRACKET -> "BracketRight";
            case InputConstants.KEY_BACKSLASH -> "Backslash";
            case InputConstants.KEY_SEMICOLON -> "Semicolon";
            case InputConstants.KEY_APOSTROPHE -> "Quote";
            case InputConstants.KEY_GRAVE -> "Backquote";
            case InputConstants.KEY_COMMA -> "Comma";
            case InputConstants.KEY_PERIOD -> "Period";
            case InputConstants.KEY_SLASH -> "Slash";
            case InputConstants.KEY_LEFT -> "ArrowLeft";
            case InputConstants.KEY_RIGHT -> "ArrowRight";
            case InputConstants.KEY_UP -> "ArrowUp";
            case InputConstants.KEY_DOWN -> "ArrowDown";
            case InputConstants.KEY_HOME -> "Home";
            case InputConstants.KEY_END -> "End";
            case InputConstants.KEY_PAGEUP -> "PageUp";
            case InputConstants.KEY_PAGEDOWN -> "PageDown";
            case InputConstants.KEY_DELETE -> "Delete";
            case InputConstants.KEY_INSERT -> "Insert";
            case InputConstants.KEY_LSHIFT -> "ShiftLeft";
            case InputConstants.KEY_RSHIFT -> "ShiftRight";
            case InputConstants.KEY_LCONTROL -> "ControlLeft";
            case InputConstants.KEY_RCONTROL -> "ControlRight";
            case InputConstants.KEY_LALT -> "AltLeft";
            case InputConstants.KEY_RALT -> "AltRight";
            case InputConstants.KEY_LGUI -> "MetaLeft";
            case InputConstants.KEY_RGUI -> "MetaRight";
            default -> "Unidentified";
        };
    }

    static String key(int scancode, int keycode, boolean shift) {
        String named = switch (scancode) {
            case InputConstants.KEY_RETURN, InputConstants.KEY_NUMPADENTER -> "Enter";
            case InputConstants.KEY_ESCAPE -> "Escape";
            case InputConstants.KEY_BACKSPACE -> "Backspace";
            case InputConstants.KEY_TAB -> "Tab";
            case InputConstants.KEY_SPACE -> " ";
            case InputConstants.KEY_LEFT -> "ArrowLeft";
            case InputConstants.KEY_RIGHT -> "ArrowRight";
            case InputConstants.KEY_UP -> "ArrowUp";
            case InputConstants.KEY_DOWN -> "ArrowDown";
            case InputConstants.KEY_HOME -> "Home";
            case InputConstants.KEY_END -> "End";
            case InputConstants.KEY_PAGEUP -> "PageUp";
            case InputConstants.KEY_PAGEDOWN -> "PageDown";
            case InputConstants.KEY_DELETE -> "Delete";
            case InputConstants.KEY_INSERT -> "Insert";
            case InputConstants.KEY_LSHIFT, InputConstants.KEY_RSHIFT -> "Shift";
            case InputConstants.KEY_LCONTROL, InputConstants.KEY_RCONTROL -> "Control";
            case InputConstants.KEY_LALT, InputConstants.KEY_RALT -> "Alt";
            case InputConstants.KEY_LGUI, InputConstants.KEY_RGUI -> "Meta";
            default -> null;
        };
        if (named != null) return named;
        if (scancode >= InputConstants.KEY_F1 && scancode <= InputConstants.KEY_F12) return code(scancode);
        // Printable keys: SDL keycodes are the unshifted character of the current layout.
        if (keycode > 0 && keycode < 0x40000000 && Character.isValidCodePoint(keycode) && !Character.isISOControl(keycode)) {
            String ch = Character.toString(keycode);
            return shift ? ch.toUpperCase() : ch;
        }
        return "Unidentified";
    }

    /**
     * The SDL key event that gives DOM key {@code key} on the current keyboard layout: the inverse of {@link #key},
     * the first scancode whose key, unshifted or with shift, is {@code key}. Null when no key gives it.
     */
    static @Nullable KeyEvent event(String key) {
        for (int scancode = 1; scancode < SDLScancode.SDL_SCANCODE_COUNT; scancode++) {
            int keycode = SDLKeyboard.SDL_GetKeyFromScancode(scancode, (short) 0, false);
            if (key.equals(key(scancode, keycode, false))) return new KeyEvent(scancode, keycode, 0);
            if (key.equals(key(scancode, keycode, true))) return new KeyEvent(scancode, keycode, InputConstants.MOD_SHIFT);
        }
        return null;
    }

    /** Escape, with or without shift, as the keyboard sends it. */
    static KeyEvent escape(boolean shift) {
        return new KeyEvent(InputConstants.KEY_ESCAPE, 0, shift ? InputConstants.MOD_SHIFT : 0);
    }

    static Modifiers modifiers(int mods) {
        return new Modifiers((mods & InputConstants.MOD_SHIFT) != 0, (mods & InputConstants.MOD_CONTROL) != 0,
                (mods & InputConstants.MOD_ALT) != 0, (mods & InputConstants.MOD_SUPER) != 0);
    }

    /** Modifier state now, for input that carries none (pointer moves, scrolling). */
    static Modifiers current() {
        return new Modifiers(isDown(InputConstants.KEY_LSHIFT, InputConstants.KEY_RSHIFT), isDown(InputConstants.KEY_LCONTROL, InputConstants.KEY_RCONTROL),
                isDown(InputConstants.KEY_LALT, InputConstants.KEY_RALT), isDown(InputConstants.KEY_LGUI, InputConstants.KEY_RGUI));
    }

    private static boolean isDown(int left, int right) {
        return InputConstants.isKeyDown(left) || InputConstants.isKeyDown(right);
    }

    /** SDL mouse buttons (1 left, 2 middle, 3 right) to DOM buttons (0, 1, 2); others pass through shifted. */
    static int button(int sdlButton) {
        return sdlButton - 1;
    }

    /** DOM buttons (0 left, 1 middle, 2 right) to SDL's. */
    static int mcButton(int domButton) {
        return domButton + 1;
    }
}
