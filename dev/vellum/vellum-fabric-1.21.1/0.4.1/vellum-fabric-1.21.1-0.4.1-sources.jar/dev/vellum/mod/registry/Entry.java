package dev.vellum.mod.registry;

import java.util.function.Supplier;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;

/**
 * A registry entry declared in common code and created lazily by the loader during its registration
 * phase (NeoForge {@code RegisterEvent}, Fabric {@code onInitialize}).
 */
public final class Entry<T> implements Supplier<T> {
    private final class_5321<? extends class_2378<T>> registry;
    private final class_2960 id;
    private final Supplier<? extends T> factory;
    private T value;

    Entry(class_5321<? extends class_2378<T>> registry, class_2960 id, Supplier<? extends T> factory) {
        this.registry = registry;
        this.id = id;
        this.factory = factory;
    }

    public class_5321<? extends class_2378<T>> registry() {
        return registry;
    }

    public class_2960 id() {
        return id;
    }

    /** Creates the value (once). Called by the loader while its registry is open. */
    public T create() {
        if (value == null) value = factory.get();
        return value;
    }

    @Override
    public T get() {
        if (value == null) throw new IllegalStateException("Registry entry " + id + " used before registration");
        return value;
    }
}
