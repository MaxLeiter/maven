package dev.vellum.mod.client;

import dev.vellum.engine.event.Modifiers;
import dev.vellum.mod.client.input.KeyEvent;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.jspecify.annotations.Nullable;
import org.lwjgl.glfw.GLFW;

/**
 * Minecraft's input to DOM names, on 1.21.1 (GLFW). {@code code} comes from the GLFW key code, which names a key by
 * its place on a US keyboard ({@code KeyA}, {@code Digit1}, {@code ArrowLeft}); {@code key} from what GLFW says the
 * key types on the current layout ({@code a}, {@code A} with shift, {@code Enter}, {@code Escape}). Each Minecraft
 * version has its own KeyNames.
 */
final class KeyNames {
    /** The GLFW key codes, from space to the last one. */
    private static final int FIRST_KEY = GLFW.GLFW_KEY_SPACE, LAST_KEY = GLFW.GLFW_KEY_LAST;

    private KeyNames() {}

    /** The DOM {@code code} of a key event: the physical key. */
    static String code(KeyEvent e) {
        return code(e.key());
    }

    /** The DOM {@code key} of a key event: what the key means on the current layout, with shift. */
    static String key(KeyEvent e) {
        return key(e.key(), e.scancode(), e.hasShiftDown());
    }

    static String code(int key) {
        if (key >= class_3675.field_32015 && key <= class_3675.field_31915) return "Key" + (char) ('A' + key - class_3675.field_32015);
        if (key >= class_3675.field_31940 && key <= class_3675.field_32014) return "Digit" + (key - class_3675.field_31940);
        if (key >= class_3675.field_31916 && key <= class_3675.field_31927) return "F" + (key - class_3675.field_31916 + 1);
        return switch (key) {
            case class_3675.field_31957 -> "Enter";
            case class_3675.field_31980 -> "NumpadEnter";
            case class_3675.field_31958 -> "Escape";
            case class_3675.field_31986 -> "Backspace";
            case class_3675.field_31948 -> "Tab";
            case class_3675.field_31947 -> "Space";
            case class_3675.field_31941 -> "Minus";
            case class_3675.field_31937 -> "Equal";
            case class_3675.field_31939 -> "BracketLeft";
            case class_3675.field_31944 -> "BracketRight";
            case class_3675.field_31935 -> "Backslash";
            case class_3675.field_31945 -> "Semicolon";
            case class_3675.field_31934 -> "Quote";
            case class_3675.field_31938 -> "Backquote";
            case class_3675.field_31936 -> "Comma";
            case class_3675.field_31943 -> "Period";
            case class_3675.field_31946 -> "Slash";
            case class_3675.field_31983 -> "ArrowLeft";
            case class_3675.field_31984 -> "ArrowRight";
            case class_3675.field_31932 -> "ArrowUp";
            case class_3675.field_31982 -> "ArrowDown";
            case class_3675.field_31989 -> "Home";
            case class_3675.field_31988 -> "End";
            case class_3675.field_31992 -> "PageUp";
            case class_3675.field_31991 -> "PageDown";
            case class_3675.field_31987 -> "Delete";
            case class_3675.field_31990 -> "Insert";
            case class_3675.field_31951 -> "ShiftLeft";
            case class_3675.field_31955 -> "ShiftRight";
            case class_3675.field_31950 -> "ControlLeft";
            case class_3675.field_31954 -> "ControlRight";
            case class_3675.field_31949 -> "AltLeft";
            case class_3675.field_31953 -> "AltRight";
            case class_3675.field_31952 -> "MetaLeft";
            case class_3675.field_31956 -> "MetaRight";
            default -> "Unidentified";
        };
    }

    static String key(int key, int scancode, boolean shift) {
        String named = switch (key) {
            case class_3675.field_31957, class_3675.field_31980 -> "Enter";
            case class_3675.field_31958 -> "Escape";
            case class_3675.field_31986 -> "Backspace";
            case class_3675.field_31948 -> "Tab";
            case class_3675.field_31947 -> " ";
            case class_3675.field_31983 -> "ArrowLeft";
            case class_3675.field_31984 -> "ArrowRight";
            case class_3675.field_31932 -> "ArrowUp";
            case class_3675.field_31982 -> "ArrowDown";
            case class_3675.field_31989 -> "Home";
            case class_3675.field_31988 -> "End";
            case class_3675.field_31992 -> "PageUp";
            case class_3675.field_31991 -> "PageDown";
            case class_3675.field_31987 -> "Delete";
            case class_3675.field_31990 -> "Insert";
            case class_3675.field_31951, class_3675.field_31955 -> "Shift";
            case class_3675.field_31950, class_3675.field_31954 -> "Control";
            case class_3675.field_31949, class_3675.field_31953 -> "Alt";
            case class_3675.field_31952, class_3675.field_31956 -> "Meta";
            default -> null;
        };
        if (named != null) return named;
        if (key >= class_3675.field_31916 && key <= class_3675.field_31927) return code(key);
        // Printable keys: GLFW names the character the key types on the current layout, unshifted.
        String typed = GLFW.glfwGetKeyName(key, scancode);
        if (typed != null && !typed.isEmpty()) {
            int cp = typed.codePointAt(0);
            if (Character.charCount(cp) == typed.length() && !Character.isISOControl(cp)) return shift ? typed.toUpperCase() : typed;
        }
        return "Unidentified";
    }

    /**
     * The key event that gives DOM key {@code key} on the current keyboard layout: the inverse of {@link #key}, the
     * first GLFW key whose key, unshifted or with shift, is {@code key}. Null when no key gives it.
     */
    static @Nullable KeyEvent event(String key) {
        for (int code = FIRST_KEY; code <= LAST_KEY; code++) {
            int scancode = GLFW.glfwGetKeyScancode(code);
            if (scancode < 0) continue; // no such key on this keyboard
            if (key.equals(key(code, scancode, false))) return new KeyEvent(code, scancode, 0);
            if (key.equals(key(code, scancode, true))) return new KeyEvent(code, scancode, GLFW.GLFW_MOD_SHIFT);
        }
        return null;
    }

    /** Escape, with or without shift, as the keyboard sends it. */
    static KeyEvent escape(boolean shift) {
        return new KeyEvent(class_3675.field_31958, GLFW.glfwGetKeyScancode(class_3675.field_31958), shift ? GLFW.GLFW_MOD_SHIFT : 0);
    }

    static Modifiers modifiers(int mods) {
        return new Modifiers((mods & GLFW.GLFW_MOD_SHIFT) != 0, (mods & GLFW.GLFW_MOD_CONTROL) != 0,
                (mods & GLFW.GLFW_MOD_ALT) != 0, (mods & GLFW.GLFW_MOD_SUPER) != 0);
    }

    /** Modifier state now, for input that carries none (pointer moves, scrolling). */
    static Modifiers current() {
        return new Modifiers(isDown(class_3675.field_31951, class_3675.field_31955), isDown(class_3675.field_31950, class_3675.field_31954),
                isDown(class_3675.field_31949, class_3675.field_31953), isDown(class_3675.field_31952, class_3675.field_31956));
    }

    private static boolean isDown(int left, int right) {
        long window = class_310.method_1551().method_22683().method_4490();
        return class_3675.method_15987(window, left) || class_3675.method_15987(window, right);
    }

    /** GLFW mouse buttons (0 left, 1 right, 2 middle) to DOM buttons (0 left, 1 middle, 2 right); others pass through. */
    static int button(int glfwButton) {
        return switch (glfwButton) {
            case GLFW.GLFW_MOUSE_BUTTON_RIGHT -> 2;
            case GLFW.GLFW_MOUSE_BUTTON_MIDDLE -> 1;
            default -> glfwButton;
        };
    }

    /** DOM buttons (0 left, 1 middle, 2 right) to GLFW's. */
    static int mcButton(int domButton) {
        return button(domButton); // the same swap both ways
    }
}
