package dev.vellum.mod;

import net.minecraft.class_2960;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class Constants {
    public static final String MOD_ID = "vellum";
    public static final String MOD_NAME = "Vellum";
    public static final Logger LOG = LoggerFactory.getLogger(MOD_NAME);

    private Constants() {}

    /** {@code vellum:<path>}. */
    public static class_2960 id(String path) {
        return class_2960.method_60655(MOD_ID, path);
    }
}
