package dev.vellum.mod.client.replaced;

import dev.vellum.engine.dom.Element;
import dev.vellum.mod.client.render.McCanvas;
import org.jspecify.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_332;

/**
 * {@code <item id="minecraft:diamond_sword" count="1" components="{...}" tooltip>}: an item stack drawn scaled from
 * 16 px to the square {@code object-fit: contain} fits in the content box (placed by {@code object-position}), with
 * count and durability. {@code components} is SNBT for the stack's data components
 * ({@link ItemStacks#of}). With the {@code tooltip} attribute, hovering shows the vanilla item tooltip, with the lines
 * of the {@code title} that applies after the item's own ({@link ItemTooltips}). The narrator reads it by the item's
 * name.
 */
final class ItemContent extends McReplaced {
    private class_1799 stack;
    private boolean tooltip;

    ItemContent(Element element) {
        super(element);
        this.stack = ItemStacks.of(element, "id");
        this.tooltip = element.hasAttribute("tooltip");
    }

    @Override
    public float intrinsicWidth() {
        return 16;
    }

    @Override
    public float intrinsicHeight() {
        return 16;
    }

    @Override
    public void attributeChanged(String name) {
        if (name.equals("id") || name.equals("count") || name.equals("components")) stack = ItemStacks.of(element, "id");
        if (name.equals("tooltip")) tooltip = element.hasAttribute("tooltip");
    }

    @Override
    public boolean showsTooltip() {
        return tooltip && !stack.method_7960();
    }

    /** The narrator reads the item by its name, as vanilla's item tooltip shows it. */
    @Override
    public @Nullable String accessibleName() {
        return stack.method_7960() ? null : stack.method_7964().getString();
    }

    @Override
    public boolean showTooltip(class_332 g, List<class_2561> extra, int x, int y) {
        if (stack.method_7960()) return false;
        ItemTooltips.show(g, stack, extra, x, y);
        return true;
    }

    /** Fills the box, which {@code object-fit: contain} (the UA's) makes a square placed by {@code object-position}. */
    @Override
    protected void draw(McCanvas canvas, float x, float y, float width, float height) {
        canvas.drawItem(stack, x, y, Math.min(width, height), true);
    }
}
