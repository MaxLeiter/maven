package dev.vellum.mod.server;

import com.google.gson.JsonObject;
import dev.vellum.mod.registry.VellumRegistry;
import net.minecraft.class_1277;
import net.minecraft.class_1661;
import net.minecraft.class_1707;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3917;
import net.minecraft.class_747;
import net.minecraft.class_7701;
import net.minecraft.class_7924;

/**
 * Server halves of the demos: a chest whose screen is the {@code chest.html} page (proving that {@code <slot>}
 * elements are real slots), and a live session that exercises the server API both ways.
 */
public final class VellumDemos {
    public static final String CHEST_PAGE = "vellum:vellum/demo/chest.html";
    public static final String LIVE_PAGE = "vellum:vellum/demo/templates.html";

    /** A plain 9×3 chest menu with its own type, so the client can give it a Vellum screen without touching chests. */
    public static final class_3917<class_1707> CHEST = new class_3917<>(VellumDemos::clientChest, class_7701.field_40182);

    private VellumDemos() {}

    public static void init() {
        VellumRegistry.add(class_7924.field_41207, "demo_chest", () -> CHEST);
    }

    private static class_1707 clientChest(int containerId, class_1661 inventory) {
        return new class_1707(CHEST, containerId, inventory, new class_1277(27), 3);
    }

    /** Opens a chest of sample items. */
    public static void openChest(class_3222 player) {
        class_1277 chest = new class_1277(27);
        class_1799[] samples = {new class_1799(class_1802.field_8802), new class_1799(class_1802.field_8463, 3), new class_1799(class_1802.field_8583, 64),
                new class_1799(class_1802.field_8634, 16), new class_1799(class_1802.field_8529), new class_1799(class_1802.field_8810, 32), new class_1799(class_1802.field_8833)};
        for (class_1799 s : samples) chest.method_5491(s);
        player.method_17355(new class_747((id, inventory, p) -> new class_1707(CHEST, id, inventory, chest, 3),
                class_2561.method_43471("vellum.demo.chest")));
    }

    /**
     * Opens the templates page as a server session: the page asks for fresh stats every second ({@code refresh}) and
     * the server pushes them; {@code say} echoes a message into the player's chat.
     */
    public static VellumSession openLive(class_3222 player) {
        VellumSession session = VellumServer.open(player, LIVE_PAGE, stats(player));
        return session
                .onMessage("refresh", (p, value) -> session.push(stats(p)))
                .onMessage("say", (p, value) -> p.method_43496(class_2561.method_43470("[Vellum] " + value.getAsString())));
    }

    private static JsonObject stats(class_3222 p) {
        JsonObject o = new JsonObject();
        o.addProperty("source", "server");
        o.addProperty("player", p.method_7334().getName());
        o.addProperty("health", Math.round(p.method_6032()));
        o.addProperty("x", p.method_31477());
        o.addProperty("y", p.method_31478());
        o.addProperty("z", p.method_31479());
        //? if >=26 {
        /*o.addProperty("time", p.level().getOverworldClockTime() % 24000);
        *///?} else
        o.addProperty("time", p.method_37908().method_8532() % 24000);
        return o;
    }
}
