package dev.vellum.mod.client;

import dev.vellum.mod.client.input.KeyEvent;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_338;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import org.jspecify.annotations.Nullable;

/**
 * The client state and input that Vellum reaches differently on each Minecraft version; this is the one for 1.21.1.
 * Every version has a McClient with the same methods ({@code common/versions/<version>/src}).
 */
public final class McClient {
    private McClient() {}

    /** The open screen, or null. */
    public static @Nullable class_437 screen() {
        return class_310.method_1551().field_1755;
    }

    /** Opens {@code screen}, or closes the open one with null. */
    public static void setScreen(@Nullable class_437 screen) {
        class_310.method_1551().method_1507(screen);
    }

    /** Whether a loading overlay (resource reload) covers the screen and takes its input. */
    public static boolean loadingOverlay() {
        return class_310.method_1551().method_18506() != null;
    }

    /** Whether the player hid the HUD (F1). */
    public static boolean hudHidden() {
        return class_310.method_1551().field_1690.field_1842;
    }

    public static class_338 chat() {
        return class_310.method_1551().field_1705.method_1743();
    }

    /** Shows a message from the client in chat. */
    public static void systemMessage(class_2561 message) {
        chat().method_1812(message);
    }

    /** Where the pointer is, in GUI px. */
    public static double mouseX() {
        class_310 mc = class_310.method_1551();
        return mc.field_1729.method_1603() * mc.method_22683().method_4486() / mc.method_22683().method_4480();
    }

    public static double mouseY() {
        class_310 mc = class_310.method_1551();
        return mc.field_1729.method_1604() * mc.method_22683().method_4502() / mc.method_22683().method_4507();
    }

    /** The local player's skin texture. */
    static class_2960 localSkin() {
        class_310 mc = class_310.method_1551();
        return mc.method_1582().method_52862(mc.method_53462()).comp_1626();
    }

    /** Text input for a text field of {@code owner}: GLFW always sends typed characters, so there is nothing to switch. */
    static void textInput(class_437 owner, boolean on) {}

    // ---- Input through Minecraft's own handlers, as a real mouse and keyboard send it (VellumAutomation) ----

    /** Moves the pointer to a window point in screen px, as the mouse handler takes a move. */
    static void moveMouse(double x, double y) {
        class_310 mc = class_310.method_1551();
        mc.field_1729.method_1599(); // takes the position without queueing a second move event
        mc.field_1729.method_1600(window(), x, y);
    }

    /** Presses or releases DOM button {@code button} (0 left, 1 middle, 2 right) where the pointer is. */
    static void mouseButton(int button, boolean press) {
        class_310.method_1551().field_1729.method_1601(window(), KeyNames.mcButton(button),
                press ? class_3675.field_31997 : class_3675.field_31998, 0);
    }

    /** Turns the wheel where the pointer is; positive {@code notches} scroll down. */
    static void scroll(double notches) {
        class_310.method_1551().field_1729.method_1598(window(), 0, -notches);
    }

    static void key(KeyEvent event, boolean press) {
        class_310.method_1551().field_1774.method_1466(window(), event.key(), event.scancode(),
                press ? class_3675.field_31997 : class_3675.field_31998, event.modifiers());
    }

    static void typeChar(int codepoint) {
        class_310.method_1551().field_1774.method_1457(window(), codepoint, 0);
    }

    private static long window() {
        return class_310.method_1551().method_22683().method_4490();
    }
}
