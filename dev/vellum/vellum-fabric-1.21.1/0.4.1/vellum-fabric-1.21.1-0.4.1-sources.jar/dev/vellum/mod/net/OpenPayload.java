package dev.vellum.mod.net;

import dev.vellum.mod.Constants;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Server → client: show a UI for a server session. Exactly one of {@code url} (a page the client has, e.g. bundled in
 * a mod or a resource pack) and {@code html} (an inline page sent by the server) is non-empty.
 *
 * @param session the server's id for this UI; messages and data refer to it
 * @param data    the initial {@code vellum.data}, a JSON value
 */
public record OpenPayload(int session, String url, String html, String data) implements class_8710 {
    public static final class_9154<OpenPayload> TYPE = new class_9154<>(Constants.id("open"));
    public static final int MAX_URL = 256;
    /** Inline pages and data stay well inside the 1 MiB clientbound payload limit, even at 3 bytes per char. */
    public static final int MAX_HTML = 200_000;
    public static final int MAX_DATA = 100_000;

    public static final class_9139<ByteBuf, OpenPayload> STREAM_CODEC = class_9139.method_56905(
            class_9135.field_48550, OpenPayload::session,
            class_9135.method_56364(MAX_URL), OpenPayload::url,
            class_9135.method_56364(MAX_HTML), OpenPayload::html,
            class_9135.method_56364(MAX_DATA), OpenPayload::data,
            OpenPayload::new);

    @Override
    public class_9154<OpenPayload> method_56479() {
        return TYPE;
    }
}
