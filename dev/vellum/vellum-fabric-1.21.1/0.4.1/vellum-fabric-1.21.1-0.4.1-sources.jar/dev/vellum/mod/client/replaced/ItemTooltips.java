package dev.vellum.mod.client.replaced;

import dev.vellum.mod.client.render.McGui;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_437;

/**
 * An {@code <item tooltip>}'s tooltip: the vanilla item tooltip, with any extra lines (the {@code title} that applies)
 * after the item's own in the same box. Item tooltips don't wrap, and neither do the extra lines. Render thread only.
 */
public final class ItemTooltips {
    /**
     * Sets a tooltip for the frame from an item's lines, as an item tooltip: with the stack's tooltip image and
     * style, and the gap after its name.
     */
    @FunctionalInterface
    public interface Setter {
        void set(class_332 g, class_327 font, List<class_2561> lines, class_1799 stack, int x, int y);
    }

    private static Setter setter = McGui::itemTooltip;

    private ItemTooltips() {}

    /**
     * Replaces how the tooltip is set. NeoForge's client entry point installs its overload that takes the stack, so
     * NeoForge's tooltip events see the item as they do for vanilla's item tooltips.
     */
    public static void install(Setter setter) {
        ItemTooltips.setter = setter;
    }

    /**
     * Shows {@code stack}'s tooltip at GUI point ({@code x}, {@code y}) for this frame, with {@code extra} after it.
     * Without extra lines it is vanilla's item tooltip.
     */
    static void show(class_332 g, class_1799 stack, List<class_2561> extra, int x, int y) {
        class_310 mc = class_310.method_1551();
        List<class_2561> lines = new ArrayList<>(class_437.method_25408(mc, stack));
        lines.addAll(extra);
        setter.set(g, mc.field_1772, lines, stack, x, y);
    }
}
