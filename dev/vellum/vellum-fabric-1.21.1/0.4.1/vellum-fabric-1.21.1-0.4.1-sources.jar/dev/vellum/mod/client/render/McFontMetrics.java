package dev.vellum.mod.client.render;

import dev.vellum.engine.host.FontFamilies;
import dev.vellum.engine.host.FontMetrics;
import dev.vellum.engine.host.FontSpec;
import dev.vellum.engine.paint.Canvas;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2477;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_5348;
import net.minecraft.class_5481;

/**
 * Text measurement with Minecraft's font, and what both measurement and {@link McCanvas#drawText} use for a
 * {@link FontSpec}: the {@link class_2583} (font, bold, italic, decorations) and the character sequence, so laid-out text
 * and painted text always agree (bold glyphs are wider).
 *
 * <p>Families resolve through {@link FontFamilies} to font ids ({@code minecraft:default | uniform | alt |
 * illageralt}, any {@code ns:id} with an {@code assets/<ns>/font/<id>.json}); a family whose font does not exist
 * falls through to the next, and the last resort is the default font. Each spec keeps its styles in its host slot;
 * the shared table is keyed without the size, so animating {@code font-size} adds nothing to it. Text is drawn as
 * written (no {@code §} formatting codes); only text with right-to-left characters, or a right-to-left language,
 * goes through Minecraft's bidi reordering and shaping. Render thread only.
 */
public final class McFontMetrics implements FontMetrics {
    public static final McFontMetrics INSTANCE = new McFontMetrics();
    private static final int CAPACITY = 256;

    /** A spec's styles, by decoration flags ({@link Canvas#UNDERLINE} | {@link Canvas#STRIKETHROUGH}). */
    private record Resolved(int generation, class_2583[] styles) {}

    private record Key(List<String> families, boolean bold, boolean italic) {}

    private final Map<Key, class_2583[]> styles = new LinkedHashMap<>(16, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<Key, class_2583[]> eldest) {
            return size() > CAPACITY;
        }
    };
    private final Map<class_2960, Boolean> knownFonts = new HashMap<>();
    /** Bumped when resources reload, which invalidates what specs hold. */
    private int generation;

    private McFontMetrics() {}

    @Override
    public float width(String text, FontSpec font) {
        return class_310.method_1551().field_1772.method_27527().method_27482(sequence(text, style(font, 0))) * font.scale();
    }

    @Override
    public float charWidth(int codePoint, FontSpec font) {
        return class_310.method_1551().field_1772.method_27527().method_27482(class_5481.method_30741(codePoint, style(font, 0)))
                * font.scale();
    }

    /** The style for a font request with text decorations ({@link Canvas#UNDERLINE} | {@link Canvas#STRIKETHROUGH}). */
    public class_2583 style(FontSpec font, int decorations) {
        class_2583[] resolved = font.hostFont() instanceof Resolved r && r.generation == generation ? r.styles : null;
        if (resolved == null) {
            resolved = styles.computeIfAbsent(new Key(font.families(), font.bold(), font.italic()), this::resolve);
            font.setHostFont(new Resolved(generation, resolved));
        }
        return resolved[decorations & 3];
    }

    /**
     * The characters Minecraft draws for {@code text}: as written, or in visual order and shaped when the text has
     * right-to-left parts.
     */
    public class_5481 sequence(String text, class_2583 style) {
        return needsBidi(text) ? class_2477.method_10517().method_30934(class_5348.method_29431(text, style))
                : class_5481.method_30747(text, style);
    }

    /** Forgets resolved fonts; resource packs may have added or removed some. */
    public void clearCache() {
        styles.clear();
        knownFonts.clear();
        generation++;
    }

    private class_2583[] resolve(Key key) {
        class_2583 base = class_2583.field_24360.method_27704(font(key.families())).method_10982(key.bold()).method_10978(key.italic());
        class_2583 underlined = base.method_30938(true);
        return new class_2583[] {base, underlined, base.method_36140(true), underlined.method_36140(true)};
    }

    //? if >=26 {
    /*private FontDescription font(List<String> families) {
        for (String family : families) {
            ResourceLocation id = ResourceLocation.tryParse(FontFamilies.fontId(family));
            if (id != null && knownFonts.computeIfAbsent(id, McFontMetrics::exists)) {
                return id.equals(FontDescription.DEFAULT.id()) ? FontDescription.DEFAULT : new FontDescription.Resource(id);
            }
        }
        return FontDescription.DEFAULT;
    }
    *///?} else {
    private class_2960 font(List<String> families) {
        for (String family : families) {
            class_2960 id = class_2960.method_12829(FontFamilies.fontId(family));
            if (id != null && knownFonts.computeIfAbsent(id, McFontMetrics::exists)) return id;
        }
        return class_2583.field_24359;
    }
    //?}

    private static boolean exists(class_2960 font) {
        class_2960 file = class_2960.method_60655(font.method_12836(), "font/" + font.method_12832() + ".json");
        return class_310.method_1551().method_1478().method_14486(file).isPresent();
    }

    private static boolean needsBidi(String text) {
        if (class_2477.method_10517().method_29428()) return true;
        for (int i = 0; i < text.length(); ) {
            int cp = text.codePointAt(i);
            i += Character.charCount(cp);
            if (cp < 0x0590) continue; // below Hebrew, everything is left to right
            switch (Character.getDirectionality(cp)) {
                case Character.DIRECTIONALITY_RIGHT_TO_LEFT, Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC,
                     Character.DIRECTIONALITY_RIGHT_TO_LEFT_EMBEDDING, Character.DIRECTIONALITY_RIGHT_TO_LEFT_OVERRIDE,
                     Character.DIRECTIONALITY_RIGHT_TO_LEFT_ISOLATE -> {
                    return true;
                }
                default -> {}
            }
        }
        return false;
    }
}
