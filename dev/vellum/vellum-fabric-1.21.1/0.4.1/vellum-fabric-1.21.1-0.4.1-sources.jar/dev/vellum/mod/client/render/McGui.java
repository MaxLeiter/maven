package dev.vellum.mod.client.render;

import com.mojang.blaze3d.platform.GlConst;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.vellum.engine.paint.ScissorStack;
import dev.vellum.engine.style.Cursor;
import org.joml.Matrix3x2f;
import org.joml.Matrix3x2fc;
import org.joml.Matrix4f;
import org.jspecify.annotations.Nullable;
import org.lwjgl.glfw.GLFW;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1041;
import net.minecraft.class_1044;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_308;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5481;
import net.minecraft.class_757;
import net.minecraft.class_8030;

/**
 * Minecraft's GUI drawing, the part of it that differs between Minecraft versions; this is the one for 1.21.1, where
 * {@link class_332} draws as it is called. Every version has a McGui with the same methods
 * ({@code common/versions/<version>/src}).
 *
 * <p>An instance is {@link McCanvas}'s backend for one frame: McCanvas keeps the transform, opacity and clip stacks and
 * computes bounds, and hands each primitive here already transformed and clipped. The static methods draw the few
 * things Vellum puts on screen without the engine (the error panel, the typing notice) and tooltips.
 *
 * <p>Order: everything is drawn in painter's order. Fills and text go through vanilla's buffer source, which draws
 * without the depth test when it is flushed; textures and sprites are drawn at once, also without it. Items are
 * 3D models that need the depth test, so after each one the depth buffer is cleared, and nothing drawn after an item
 * hides behind it.
 */
public final class McGui {
    /** How far in front of the canvas a scene's middle is drawn, so its near half is not clipped. */
    private static final float SCENE_DEPTH = 500;

    private final class_332 g;
    /** Where vanilla's pose had z when the canvas began: the canvas draws at that depth. */
    private float z;

    McGui(class_332 g) {
        this.g = g;
    }

    // ---- For McCanvas ----

    /** What can be drawn: the GUI-scaled window, within any scissor already pushed. */
    ScissorStack drawableArea() {
        int width = g.method_51421(), height = g.method_51443();
        class_8030 outer = scissor();
        return outer == null ? new ScissorStack(0, 0, width, height) : new ScissorStack(Math.max(0, outer.method_49620()),
                Math.max(0, outer.method_49618()), Math.min(width, outer.method_49621()), Math.min(height, outer.method_49619()));
    }

    /** Saves vanilla's pose for the canvas, which sets it before each call; returns the 2D transform it had. */
    Matrix3x2f begin() {
        g.method_51452();
        g.method_51448().method_22903();
        Matrix4f pose = g.method_51448().method_23760().method_23761();
        z = pose.m32();
        return new Matrix3x2f(pose.m00(), pose.m01(), pose.m10(), pose.m11(), pose.m30(), pose.m31());
    }

    /** Draws what is still buffered and puts vanilla's pose back. */
    void end() {
        g.method_51452();
        g.method_51448().method_22909();
    }

    /** Pushes a scissor, in GUI px on screen. */
    void pushScissor(int left, int top, int right, int bottom) {
        g.method_51452(); // what was buffered under the old scissor is drawn with it
        g.method_44379(left, top, right, bottom);
    }

    void popScissor() {
        g.method_51452();
        g.method_44380();
    }

    /** The scissor vanilla clips to now, or null. */
    @Nullable class_8030 scissor() {
        return g.field_44659.field_43099.peekLast();
    }

    /** Whether text in this colour shows: vanilla draws text whose alpha is under 4 opaque, so it is left out. */
    static boolean textVisible(int argb) {
        return (argb & 0xFC000000) != 0;
    }

    /** One rectangle in one colour, wound as vanilla's: (x0,y0) (x0,y1) (x1,y1) (x1,y0). */
    void fill(Matrix3x2fc pose, float x0, float y0, float x1, float y1, int color, class_8030 bounds,
              @Nullable class_8030 scissor) {
        Matrix4f m = matrix(pose);
        class_4588 out = g.method_51450().getBuffer(class_1921.method_51784());
        out.method_22918(m, x0, y0, 0).method_39415(color);
        out.method_22918(m, x0, y1, 0).method_39415(color);
        out.method_22918(m, x1, y1, 0).method_39415(color);
        out.method_22918(m, x1, y0, 0).method_39415(color);
    }

    /** A texture region (normalised UVs) multiplied by {@code color}, wound as {@link #fill}. */
    void blit(Matrix3x2fc pose, class_2960 texture, boolean smooth, float x0, float y0, float x1, float y1,
              float u0, float v0, float u1, float v1, int color, class_8030 bounds, @Nullable class_8030 scissor) {
        g.method_51452();
        Matrix4f m = matrix(pose);
        class_1044 t = class_310.method_1551().method_1531().method_4619(texture);
        if (smooth) t.method_4527(true, false);
        RenderSystem.setShaderTexture(0, texture);
        RenderSystem.setShader(class_757::method_34543);
        RenderSystem.enableBlend();
        RenderSystem.disableDepthTest();
        class_287 out = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1575);
        out.method_22918(m, x0, y0, 0).method_22913(u0, v0).method_39415(color);
        out.method_22918(m, x0, y1, 0).method_22913(u0, v1).method_39415(color);
        out.method_22918(m, x1, y1, 0).method_22913(u1, v1).method_39415(color);
        out.method_22918(m, x1, y0, 0).method_22913(u1, v0).method_39415(color);
        class_286.method_43433(out.method_60800());
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
        if (smooth) t.method_4527(false, false);
    }

    /** Quads with a colour per vertex, 4 vertices each, already wound as vanilla's. */
    void quads(Matrix3x2fc pose, float[] xy, int[] colors, class_8030 bounds, @Nullable class_8030 scissor) {
        Matrix4f m = matrix(pose);
        class_4588 out = g.method_51450().getBuffer(class_1921.method_51784());
        for (int i = 0, n = colors.length; i < n; i++) out.method_22918(m, xy[i * 2], xy[i * 2 + 1], 0).method_39415(colors[i]);
    }

    /** Text at (x, y) in {@code m}, scaled by {@code scale}. */
    void text(Matrix3x2fc m, float x, float y, float scale, class_5481 text, int color, boolean shadow) {
        Matrix4f pose = matrix(m).translate(x, y, 0).scale(scale, scale, 1);
        class_310.method_1551().field_1772.method_22942(text, 0, 0, color, shadow, pose, g.method_51450(), class_327.class_6415.field_33993,
                0, 0xF000F0);
    }

    /** A GUI sprite (nine-slice and tiling at its integer size {@code w × h}), at (x, y) in {@code m} scaled by (sx, sy). */
    void sprite(Matrix3x2fc m, float x, float y, float sx, float sy, class_2960 sprite, int w, int h, int color) {
        g.method_51452();
        setPose(m).translate(x, y, 0).scale(sx, sy, 1);
        g.method_51422((color >> 16 & 0xFF) / 255f, (color >> 8 & 0xFF) / 255f, (color & 0xFF) / 255f, (color >>> 24) / 255f);
        RenderSystem.enableBlend();
        RenderSystem.disableDepthTest();
        g.method_52706(sprite, 0, 0, w, h);
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
        g.method_51422(1, 1, 1, 1);
    }

    /** An item at (x, y) in {@code m}, scaled from its 16 px, with count and durability when asked. */
    void item(Matrix3x2fc m, float x, float y, float scale, class_1799 stack, boolean decorations) {
        g.method_51452();
        setPose(m).translate(x, y, 0).scale(scale, scale, 1);
        g.method_51427(stack, 0, 0);
        if (decorations) g.method_51431(class_310.method_1551().field_1772, stack, 0, 0);
        g.method_51452();
        clearDepth();
    }

    /**
     * A 3D scene in a screen box, a block {@code scale} GUI px, multiplied by {@code color}: drawn straight into the
     * GUI (1.21.1 has no picture-in-picture renderers), clipped to the box and the scissor, with a depth buffer of its
     * own. Models are opaque here, so the colour tints them but its alpha cannot fade them: like items, a scene under
     * half opacity is not drawn.
     */
    void scene(Scene scene, int color, int x0, int y0, int x1, int y1, float scale, @Nullable class_8030 scissor) {
        if (color >>> 24 < 128) return;
        g.method_51452();
        clearDepth();
        g.method_44379(x0, y0, x1, y1); // within the scissor already pushed
        class_4587 pose = g.method_51448();
        pose.method_22903();
        pose.method_23760().method_23761().translation((x0 + x1) / 2F, (y0 + y1) / 2F, z + SCENE_DEPTH);
        pose.method_23760().method_23762().identity();
        pose.method_22905(scale, scale, -scale);
        RenderSystem.setShaderColor((color >> 16 & 0xFF) / 255F, (color >> 8 & 0xFF) / 255F, (color & 0xFF) / 255F, 1);
        scene.draw(pose, g.method_51450(), new Scene.Box(x0, y0, x1, y1, scale));
        g.method_51452();
        RenderSystem.setShaderColor(1, 1, 1, 1);
        class_308.method_24211(); // the GUI's lighting, as vanilla leaves it after its models
        pose.method_22909();
        g.method_44380();
        clearDepth();
    }

    /** {@code pose} as a 4×4 matrix at the canvas's depth. */
    private Matrix4f matrix(Matrix3x2fc pose) {
        return new Matrix4f(pose.m00(), pose.m01(), 0, 0, pose.m10(), pose.m11(), 0, 0, 0, 0, 1, 0, pose.m20(), pose.m21(), z, 1);
    }

    /** Sets vanilla's pose to {@code m} at the canvas's depth, for the vanilla calls that read it. */
    private Matrix4f setPose(Matrix3x2fc m) {
        Matrix4f pose = g.method_51448().method_23760().method_23761();
        pose.set(matrix(m));
        return pose;
    }

    // ---- Panels, tooltips, the cursor ----

    /**
     * From here on, everything is drawn above what was drawn before: what is buffered is drawn, and the depth buffer
     * cleared so no item hides what follows.
     */
    public static void nextLayer(class_332 g) {
        g.method_51452();
        clearDepth();
    }

    public static void fill(class_332 g, int x0, int y0, int x1, int y1, int color) {
        g.method_25294(x0, y0, x1, y1, color);
    }

    public static void outline(class_332 g, int x, int y, int width, int height, int color) {
        g.method_49601(x, y, width, height, color);
    }

    public static void text(class_332 g, class_327 font, class_5481 text, int x, int y, int color, boolean shadow) {
        g.method_51430(font, text, x, y, color, shadow);
    }

    public static void text(class_332 g, class_327 font, class_2561 text, int x, int y, int color, boolean shadow) {
        g.method_51439(font, text, x, y, color, shadow);
    }

    public static void text(class_332 g, class_327 font, String text, int x, int y, int color, boolean shadow) {
        g.method_51433(font, text, x, y, color, shadow);
    }

    /** A tooltip of already wrapped lines, drawn now (1.21.1 has no deferred tooltips outside screens). */
    public static void tooltip(class_332 g, class_327 font, List<class_5481> lines, int x, int y) {
        g.method_51447(font, lines, x, y);
    }

    /** A tooltip of lines that are not wrapped, drawn now. */
    public static void componentTooltip(class_332 g, class_327 font, List<class_2561> lines, int x, int y) {
        g.method_51434(font, lines, x, y);
    }

    /** An item tooltip of {@code lines} (the item's own and any after them), with the stack's tooltip image, drawn now. */
    public static void itemTooltip(class_332 g, class_327 font, List<class_2561> lines, class_1799 stack, int x, int y) {
        g.method_51437(font, lines, stack.method_32347(), x, y);
    }

    /** Tooltips are drawn as they are asked for on this version, so there is nothing left to draw. */
    public static void drawTooltipsNow(class_332 g, int mouseX, int mouseY, float partialTick) {}

    private static final Map<Cursor, Long> CURSORS = new EnumMap<>(Cursor.class);
    private static long shown;

    /**
     * Shows the CSS cursor a screen's page asks for while the pointer is over it, with GLFW's standard cursors
     * (vanilla 1.21.1 has no cursors of its own). It stays until another is asked for or {@link #resetCursor}. HUD
     * overlays ({@code screen} false) don't set the cursor on this version: with no cursor of vanilla's to ask, the last
     * page drawn would win, whatever is under the pointer.
     */
    public static void cursor(class_332 g, Cursor cursor, boolean screen) {
        if (!screen) return;
        int shape = switch (cursor) {
            case POINTER, GRAB, GRABBING -> GLFW.GLFW_HAND_CURSOR;
            case TEXT -> GLFW.GLFW_IBEAM_CURSOR;
            case EW_RESIZE -> GLFW.GLFW_HRESIZE_CURSOR;
            case NS_RESIZE -> GLFW.GLFW_VRESIZE_CURSOR;
            case MOVE -> GLFW.GLFW_RESIZE_ALL_CURSOR;
            case NOT_ALLOWED -> GLFW.GLFW_NOT_ALLOWED_CURSOR;
            case CROSSHAIR -> GLFW.GLFW_CROSSHAIR_CURSOR;
            default -> 0;
        };
        show(shape == 0 ? 0L : CURSORS.computeIfAbsent(cursor, c -> GLFW.glfwCreateStandardCursor(shape)));
    }

    /** Back to the system's arrow: the page that asked for a cursor is gone. */
    public static void resetCursor() {
        show(0L);
    }

    private static void show(long handle) {
        if (handle == shown) return;
        shown = handle;
        class_1041 window = class_310.method_1551().method_22683();
        GLFW.glfwSetCursor(window.method_4490(), handle);
    }

    private static void clearDepth() {
        RenderSystem.clear(GlConst.GL_DEPTH_BUFFER_BIT, class_310.field_1703);
    }
}
