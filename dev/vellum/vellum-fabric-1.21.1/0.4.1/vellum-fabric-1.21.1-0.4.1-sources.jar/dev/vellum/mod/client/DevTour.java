package dev.vellum.mod.client;

import java.util.Deque;
import net.minecraft.class_310;

/** The scripted showcase tour for demo videos ({@code -Ptour}) is recorded on 26.x only; on 1.21.1 it is off. */
final class DevTour {
    static final boolean ENABLED = false;

    private DevTour() {}

    static void plan(class_310 mc, Deque<Runnable> steps) {}
}
