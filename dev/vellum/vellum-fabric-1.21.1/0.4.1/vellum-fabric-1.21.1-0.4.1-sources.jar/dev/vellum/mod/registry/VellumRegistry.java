package dev.vellum.mod.registry;

import dev.vellum.mod.Constants;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_2378;
import net.minecraft.class_5321;

/** All of the mod's registry entries, in declaration order. Loaders iterate this to register them. */
public final class VellumRegistry {
    private static final List<Entry<?>> ENTRIES = new ArrayList<>();

    private VellumRegistry() {}

    public static <T> Entry<T> add(class_5321<? extends class_2378<T>> registry, String path, Supplier<? extends T> factory) {
        Entry<T> e = new Entry<>(registry, Constants.id(path), factory);
        ENTRIES.add(e);
        return e;
    }

    public static List<Entry<?>> entries() {
        return Collections.unmodifiableList(ENTRIES);
    }
}
