package dev.vellum.mod.server;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.class_2168;
import net.minecraft.class_2170;

/**
 * Server commands: {@code /vellum demo chest | live}. The client registers the rest of {@code /vellum} (open, demo
 * pages, reload) and forwards these two here ({@code VellumClientCommands.SERVER_DEMOS}).
 */
public final class VellumCommand {
    private VellumCommand() {}

    public static void register(CommandDispatcher<class_2168> d) {
        d.register(class_2170.method_9247("vellum")
                //? if >=26 {
                /*.then(Commands.literal("demo").requires(Commands.hasPermission(Commands.LEVEL_GAMEMASTERS))
                *///?} else
                .then(class_2170.method_9247("demo").requires(source -> source.method_9259(class_2170.field_31839))
                        .then(class_2170.method_9247("chest").executes(c -> {
                            VellumDemos.openChest(c.getSource().method_9207());
                            return 1;
                        }))
                        .then(class_2170.method_9247("live").executes(c -> {
                            VellumDemos.openLive(c.getSource().method_9207());
                            return 1;
                        }))));
    }
}
