package dev.vellum.mod.client.replaced;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.serialization.Codec;
import dev.vellum.engine.dom.Element;
import dev.vellum.mod.Constants;
import org.jspecify.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2520;
import net.minecraft.class_2522;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_7923;

/**
 * Item stacks and data components from element attributes: {@code <item>}, {@code <model item>} and an
 * {@code <entity>}'s equipment and components. Malformed SNBT and components that don't decode are logged and left
 * out.
 */
final class ItemStacks {
    private ItemStacks() {}

    /** The stack {@code element} names: item {@code idAttr}, with its {@code count} and {@code components}. */
    static class_1799 of(Element element, String idAttr) {
        return parse(element.getAttribute(idAttr), Math.max(1, (int) element.numberAttribute("count", 1)),
                element.getAttribute("components"));
    }

    /**
     * The stack of item {@code id} (empty when the id is blank or unknown). {@code components} is SNBT for its data
     * components, as in {@code /give}, parsed with the world's registries; when it is malformed, the plain item.
     */
    static class_1799 parse(@Nullable String id, int count, @Nullable String components) {
        class_2960 item = id == null ? null : class_2960.method_12829(id.strip());
        if (item == null) return class_1799.field_8037;
        class_2487 parsed = components == null ? null : snbt(components, "<item components>");
        if (parsed != null) {
            class_2487 tag = new class_2487();
            tag.method_10582("id", item.toString());
            tag.method_10569("count", count);
            tag.method_10566("components", parsed);
            Optional<class_1799> stack = decode(class_1799.field_24671, tag, "<item components>");
            if (stack.isPresent()) return stack.get();
        }
        return class_7923.field_41178.method_17966(item).map(i -> new class_1799(i, count)).orElse(class_1799.field_8037);
    }

    /** {@code text} parsed as an SNBT compound, or null (logged) when it is not one. {@code what} names it in the log. */
    static @Nullable class_2487 snbt(String text, String what) {
        try {
            //? if >=26 {
            /*return TagParser.parseCompoundFully(text);
            *///?} else
            return class_2522.method_10718(text);
        } catch (CommandSyntaxException e) {
            Constants.LOG.warn("Vellum: {} is not SNBT: {}", what, e.getMessage());
            return null;
        }
    }

    /** {@code tag} decoded with the world's registries, as much of it as decodes (errors are logged); empty without a world. */
    static <T> Optional<T> decode(Codec<T> codec, class_2520 tag, String what) {
        class_1937 level = class_310.method_1551().field_1687;
        if (level == null) return Optional.empty();
        return codec.parse(level.method_30349().method_57093(class_2509.field_11560), tag)
                .resultOrPartial(error -> Constants.LOG.warn("Vellum: {}: {}", what, error));
    }
}
