package dev.vellum.mod.client.replaced;

import dev.vellum.engine.style.ComputedStyle;
import dev.vellum.engine.style.EntityFocus;
import dev.vellum.engine.style.EntityFraming;
import dev.vellum.mod.client.render.McCanvas;
import dev.vellum.mod.client.render.Scene;
import org.joml.Quaternionf;
import org.jspecify.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_156;
import net.minecraft.class_1937;
import net.minecraft.class_290;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_765;

/**
 * Draws a live entity fitted into a box, as vanilla's inventory does for the player, as a {@link Scene}. Any number of
 * entities, even of one type, can be drawn in a frame. The framing is the 26.x EntityPortrait's: the body fit (the
 * largest size at which the model fits under a small top and side margin at the current pitch and any turn, placed by
 * {@code object-position}) and the eyes fit ({@code -mc-entity-focus: eyes}).
 *
 * <p>On Minecraft 1.21.1 entities have no render states: the entity's own fields are posed for the draw and put back
 * after it, as vanilla's inventory poses the player. Its body turn, head, walk and age are set from the pose; its scale
 * attribute is divided out; it has no shadow and is lit full bright. A mod can't supply a render state of its own
 * ({@code VellumEntities.registerPortraitState} is 26.x only). The model's reach is measured from the vertices the
 * renderer draws, in a neutral pose. Display entities' idle animations follow the clock.
 */
public final class EntityPortrait {
    /** Free space above the entity, as a fraction of the box height. */
    private static final float TOP_MARGIN = 0.08f;
    /** Free space on each side, as a fraction of the box width. */
    private static final float SIDE_MARGIN = 0.05f;

    /**
     * How the entity is shown, in degrees. {@code yaw} turns it (0 faces the viewer, positive turns its front to the
     * right) and {@code pitch} views it from above (positive) or below. With {@code followMouse} it turns its head
     * toward the pointer ({@link #draw}); {@code scale} multiplies the size that fits the box and {@code walk} swings
     * its limbs at that speed (0 stands still).
     */
    public record Pose(float yaw, float pitch, boolean followMouse, float scale, float walk) {
        public static final Pose FRONT = new Pose(0, 0, false, 1, 0);
    }

    /** How far a type's model reaches, in blocks from its feet at scale 1 ({@link #reach}). */
    private record Reach(float radius, float bottom, float top) {}

    private record ReachKey(class_1299<?> type, boolean baby, float width, float height) {}

    private static final Map<ReachKey, Reach> MEASURED = new HashMap<>();

    /**
     * Display entities get negative ids: renderers need one, and real entities' ids are positive. They never tick, so
     * their idle animations play on the clock.
     */
    private static int nextDisplayId = -1;

    private EntityPortrait() {}

    /** An entity for display only, never added to the world. */
    public static @Nullable class_1297 create(class_1299<?> type, class_1937 level) {
        if (!type.method_45382(level.method_45162())) return null;
        class_1297 entity = type.method_5883(level);
        if (entity != null) entity.method_5838(nextDisplayId--);
        return entity;
    }

    /**
     * Draws {@code entity} into the box {@code (x, y, width, height)} in the canvas's current transform, tinted by
     * {@code tint} (ARGB; white for none; models can't fade on 1.21.1, so under half opacity nothing is drawn),
     * framed by {@code style}'s {@code -mc-entity-focus} and {@code object-position}. With {@code followMouse} the head
     * turns toward the canvas's pointer as vanilla's inventory turns the player's, as far as {@code style}'s
     * {@code -mc-gaze-reach} and {@code -mc-gaze-limit} let it, and the body leans half of that turn; otherwise the
     * head looks ahead.
     */
    public static void draw(McCanvas canvas, class_1297 entity, Pose pose, ComputedStyle style, int tint, float x, float y, float width, float height) {
        if (!canvas.sceneVisible(tint, x, y, width, height)) return;
        class_310 mc = class_310.method_1551();
        boolean display = entity.method_5628() < 0;
        float partialTick = display ? class_156.method_658() % 50 / 50F : mc.method_60646().method_60637(false);
        float age = display ? class_156.method_658() / 50F : entity.field_6012 + partialTick;

        // The point it looks from: with the eyes focus, also where its eyes go.
        float[] eyes = EntityFraming.gazeOrigin(style, x, y, width, height);
        boolean gazes = pose.followMouse() && canvas.mouseX() >= 0;
        float gazeYaw = gazes ? style.gazeYaw(canvas.mouseX() - eyes[0]) : 0;
        float gazePitch = gazes ? style.gazePitch(eyes[1] - canvas.mouseY()) : 0;
        // The body leans half of the gaze and the head turns the other half on top.
        float leanYaw = gazeYaw / 2, leanPitch = gazePitch / 2;
        // Leaning toward the gaze tilts the view the other way: looking up shows it from below.
        float tilt = leanPitch - pose.pitch();
        Quaternionf view = new Quaternionf().rotateX(tilt * class_3532.field_29847);
        Quaternionf rotation = new Quaternionf().rotateZ(class_3532.field_29844).mul(view);
        class_1309 living = entity instanceof class_1309 l ? l : null;
        if (living == null) rotation.mul(new Quaternionf().rotateY(pose.yaw() * class_3532.field_29847));

        // Sizes at scale 1: the entity's own scale (scaled mobs) is divided out, to fit the box instead.
        float ownScale = living != null ? living.method_55693() : 1;
        float eyeHeight = entity.method_5751() / ownScale;
        EntityFraming frame;
        if (style.entityFocus == EntityFocus.EYES) {
            frame = EntityFraming.eyes(eyes[0], eyes[1], width, height, eyeHeight, tilt, pose.scale());
        } else {
            Reach reach = reach(entity, ownScale);
            float sweep = 2 * reach.radius(), tall = Math.max(0.3F, reach.top() - reach.bottom());
            float sin = Math.abs(class_3532.method_15374(pose.pitch() * class_3532.field_29847)), cos = Math.abs(class_3532.method_15362(pose.pitch() * class_3532.field_29847));
            // The room it takes, seen from this pitch. Its origin is lifted off the room's bottom by what hangs below
            // the feet and, seen from above or below, by the near or far side of what it sweeps.
            float roomHeight = tall * cos + sweep * sin, lift = -reach.bottom() * cos + sweep / 2 * sin;
            float fitted = Math.min(height * (1 - TOP_MARGIN) / roomHeight, width * (1 - 2 * SIDE_MARGIN) / sweep) * pose.scale();
            frame = EntityFraming.body(style, x, y, width, height, fitted, sweep, roomHeight, lift);
        }
        float pixelsPerBlock = frame.pixelsPerBlock();
        float dx = (frame.originX() - x - width / 2) / pixelsPerBlock, up = (y + height - frame.originY()) / pixelsPerBlock;
        // The entity's scale attribute is applied by its renderer: a block of the picture is pixelsPerBlock / ownScale.
        Scene scene = Scene.entity(entity, partialTick, dx * ownScale, up * ownScale, rotation, view);

        Posed posed = Posed.save(entity, living);
        try {
            if (display) entity.field_6012 = (int) age;
            if (living != null) {
                float body = 180.0F - pose.yaw() - leanYaw;
                living.field_6283 = living.field_6220 = body;
                living.field_6241 = living.field_6259 = body - leanYaw;
                living.method_36456(body);
                living.field_5982 = body;
                living.method_36457(-leanPitch);
                living.field_6004 = -leanPitch;
                living.field_42108.method_48567(pose.walk());
                living.field_42108.field_42111 = age * pose.walk();
            }
            canvas.drawScene(scene, pixelsPerBlock / ownScale, tint, x, y, width, height);
        } finally {
            posed.restore(entity, living);
        }
    }

    /** The fields {@link #draw} poses, to put back: world entities keep moving after the GUI has drawn them. */
    private record Posed(int tickCount, float yRot, float yRotO, float xRot, float xRotO, float body, float bodyO,
                         float head, float headO, float walkSpeed, float walkPosition) {
        static Posed save(class_1297 e, @Nullable class_1309 l) {
            return new Posed(e.field_6012, e.method_36454(), e.field_5982, e.method_36455(), e.field_6004, l == null ? 0 : l.field_6283, l == null ? 0 : l.field_6220,
                    l == null ? 0 : l.field_6241, l == null ? 0 : l.field_6259, l == null ? 0 : l.field_42108.method_48566(),
                    l == null ? 0 : l.field_42108.field_42111);
        }

        void restore(class_1297 e, @Nullable class_1309 l) {
            e.field_6012 = tickCount;
            e.method_36456(yRot);
            e.field_5982 = yRotO;
            e.method_36457(xRot);
            e.field_6004 = xRotO;
            if (l == null) return;
            l.field_6283 = body;
            l.field_6220 = bodyO;
            l.field_6241 = head;
            l.field_6259 = headO;
            l.field_42108.method_48567(walkSpeed);
            l.field_42108.field_42111 = walkPosition;
        }
    }

    /**
     * How far the entity's model reaches at scale 1, never less than its bounding box: measured once per type, age
     * and size by drawing it, in a neutral pose (looking ahead, standing still, at age 0), into a buffer that only
     * reads where the entity's vertices are.
     */
    private static Reach reach(class_1297 entity, float ownScale) {
        class_1309 living = entity instanceof class_1309 l ? l : null;
        float width = entity.method_17681() / ownScale, height = entity.method_17682() / ownScale;
        ReachKey key = new ReachKey(entity.method_5864(), living != null && living.method_6109(), width, height);
        Reach reach = MEASURED.get(key);
        if (reach == null) MEASURED.put(key, reach = measure(entity, living, width, height, ownScale));
        return reach;
    }

    private static Reach measure(class_1297 entity, @Nullable class_1309 living, float width, float height, float ownScale) {
        Extent extent = new Extent();
        Posed posed = Posed.save(entity, living);
        try {
            entity.field_6012 = 0;
            entity.method_36457(0);
            entity.field_6004 = 0;
            if (living != null) {
                living.field_6241 = living.field_6259 = living.field_6283;
                living.field_6220 = living.field_6283;
                living.field_42108.method_48567(0);
                living.field_42108.field_42111 = 0;
            }
            var dispatcher = class_310.method_1551().method_1561();
            dispatcher.method_3948(false);
            dispatcher.method_3954(entity, 0, 0, 0, 0, 1, new class_4587(),
                    type -> type.method_23031() == class_290.field_1580 ? extent : Extent.IGNORED, class_765.field_32767);
            dispatcher.method_3948(true);
        } catch (RuntimeException e) {
            extent.bottom = Float.POSITIVE_INFINITY; // a renderer that can't draw without a world: the box it is
        } finally {
            posed.restore(entity, living);
        }
        float boxRadius = width / (float) Math.sqrt(2);
        if (extent.bottom == Float.POSITIVE_INFINITY) return new Reach(width, 0, height); // turning takes twice the box
        return new Reach(Math.max(boxRadius, extent.radius / ownScale), Math.min(0, extent.bottom / ownScale),
                Math.max(height, extent.top / ownScale));
    }

    /** Takes the positions of the vertices drawn into it; everything else is dropped. */
    private static final class Extent implements class_4588 {
        static final Extent IGNORED = new Extent();

        float radius, bottom = Float.POSITIVE_INFINITY, top = Float.NEGATIVE_INFINITY;

        @Override
        public class_4588 method_22912(float x, float y, float z) {
            if (this != IGNORED) {
                radius = Math.max(radius, (float) Math.sqrt(x * x + z * z));
                bottom = Math.min(bottom, y);
                top = Math.max(top, y);
            }
            return this;
        }

        @Override
        public class_4588 method_1336(int r, int g, int b, int a) {
            return this;
        }

        @Override
        public class_4588 method_22913(float u, float v) {
            return this;
        }

        @Override
        public class_4588 method_60796(int u, int v) {
            return this;
        }

        @Override
        public class_4588 method_22921(int u, int v) {
            return this;
        }

        @Override
        public class_4588 method_22914(float x, float y, float z) {
            return this;
        }
    }
}
