package dev.vellum.mod.client;

import com.google.gson.JsonParser;
import com.mojang.serialization.JsonOps;
import dev.vellum.engine.css.CssColors;
import dev.vellum.engine.host.Host;
import dev.vellum.mod.Constants;
import org.jspecify.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_5250;
import net.minecraft.class_8824;

/**
 * Chat components for {@code <mc-text json>} ({@link Host#formatText}): the component's text (translations
 * resolved), as runs styled with CSS for its colour, bold, italic, underline, strikethrough and font. The engine
 * turns the runs into the element's children. {@code title-json} tooltips parse the same way ({@link #component}), and
 * come apart into lines at newlines ({@link #lines}).
 */
final class McText {
    private McText() {}

    /** The runs of a chat component in JSON, or null when it is malformed. */
    static @Nullable List<Host.TextRun> runs(String json) {
        class_2561 text = component(json);
        if (text == null) return null;
        List<Host.TextRun> runs = new ArrayList<>();
        text.method_27658((style, part) -> {
            runs.add(new Host.TextRun(part, css(style)));
            return Optional.empty();
        }, class_2583.field_24360);
        return runs;
    }

    /** A chat component from JSON (with the world's registries when there is one), or null when it is malformed. */
    static @Nullable class_2561 component(String json) {
        try {
            var level = class_310.method_1551().field_1687;
            var ops = level == null ? JsonOps.INSTANCE : level.method_30349().method_57093(JsonOps.INSTANCE);
            return class_8824.field_46597.parse(ops, JsonParser.parseString(json)).result().orElse(null);
        } catch (RuntimeException e) {
            Constants.LOG.warn("Vellum: bad <mc-text json>: {}", e.toString());
            return null;
        }
    }

    /** The lines of {@code text}, split at its newlines; each keeps the styles of its parts. */
    static List<class_2561> lines(class_2561 text) {
        List<class_2561> lines = new ArrayList<>();
        class_5250[] line = {class_2561.method_43473()};
        text.method_27658((style, part) -> {
            int start = 0;
            for (int end; (end = part.indexOf('\n', start)) >= 0; start = end + 1) {
                if (end > start) line[0].method_10852(class_2561.method_43470(part.substring(start, end)).method_27696(style));
                lines.add(line[0]);
                line[0] = class_2561.method_43473();
            }
            if (start < part.length()) line[0].method_10852(class_2561.method_43470(part.substring(start)).method_27696(style));
            return Optional.empty();
        }, class_2583.field_24360);
        lines.add(line[0]);
        return lines;
    }

    private static String css(class_2583 style) {
        StringBuilder css = new StringBuilder();
        if (style.method_10973() != null) css.append("color:").append(CssColors.serialize(0xFF000000 | style.method_10973().method_27716())).append(';');
        if (style.method_10984()) css.append("font-weight:bold;");
        if (style.method_10966()) css.append("font-style:italic;");
        if (style.method_10965() || style.method_10986()) {
            css.append("text-decoration:").append(style.method_10965() ? "underline " : "").append(style.method_10986() ? "line-through" : "").append(';');
        }
        //? if >=26 {
        /*if (style.getFont() instanceof FontDescription.Resource font && !font.equals(FontDescription.DEFAULT)) css.append("font-family:").append(font.id()).append(';');
        *///?} else
        if (!style.method_27708().equals(class_2583.field_24359)) css.append("font-family:").append(style.method_27708()).append(';');
        return css.toString();
    }
}
