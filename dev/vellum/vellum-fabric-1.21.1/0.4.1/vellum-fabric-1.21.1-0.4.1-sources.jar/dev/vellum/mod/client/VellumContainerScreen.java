package dev.vellum.mod.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import dev.vellum.engine.dom.Document;
import dev.vellum.engine.dom.Element;
import dev.vellum.engine.paint.Coordinates;
import dev.vellum.mod.Constants;
import dev.vellum.mod.client.render.McCanvas;
import dev.vellum.mod.client.input.CharacterEvent;
import dev.vellum.mod.client.input.KeyEvent;
import dev.vellum.mod.client.input.MouseButtonEvent;
import org.jspecify.annotations.Nullable;

import java.util.Objects;
import java.util.function.Function;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_6382;
import net.minecraft.class_7923;

/**
 * A container screen whose layout is a Vellum page. Each {@code <slot index="n">} element places menu slot
 * {@code n}: every frame the slot's 16×16 item area goes where the element's content box is painted, so slots follow
 * scrolling, transforms and animations. Slots that are not painted (no element, hidden, scrolled out of their clip)
 * move off-screen. Vanilla still draws slot items, highlights, tooltips and the carried stack, on top of the page,
 * and handles slot clicks, drags and shift-clicks; everything else goes to the page.
 *
 * <p>The screen's GUI area ({@code leftPos}, {@code topPos}, {@code imageWidth}, {@code imageHeight}, which JEI, REI
 * and other mods read to lay out beside it) is the page's content, updated every frame: the elements marked
 * {@code data-vellum-bounds}, or {@code body}'s in-flow children ({@link Coordinates#contentBounds}). Slot positions
 * are relative to it, as in vanilla.
 *
 * <p>Register one for a menu type with {@link VellumScreens#registerContainer}. The page's {@code vellum.data} is
 * {@code {title, inventory, slots: [{id, count, name}, ...]}}, plus the fields of the registration's data function
 * (the mod's own: an entity id, a tier), updated when the menu's contents or those fields change, so pages can show
 * totals, filter slots by name, or show the mod's state.
 *
 * <p>The narrator reads it as a {@link VellumScreen}: the page's {@code <title>} if it has one (else the menu's title),
 * then its focused or hovered element; a hovered {@code <slot>} reads as its item ("Item: Coal").
 */
public class VellumContainerScreen<M extends class_1703> extends class_465<M> implements DocumentDriver.Owner {
    private static final int OFF_SCREEN = -10_000;

    private final DocumentDriver driver;
    private final McCanvas.SlotSink slotSink = this::placeSlot;
    /** The mod's fields for {@code vellum.data}, or null. */
    private final @Nullable Function<? super M, ? extends JsonObject> extra;
    /** Copies of the stacks the page was last sent, so data goes out only when the menu's contents change. */
    private @Nullable class_1799[] sent = new class_1799[0];
    /** A copy of the extra fields the page was last sent. */
    private @Nullable JsonObject sentExtra;
    private boolean extraFailed;
    /** Whether the current press went to the page (its release goes there too) rather than to vanilla. */
    private boolean pagePress;

    public VellumContainerScreen(M menu, class_1661 inventory, class_2561 title, String url) {
        this(menu, inventory, title, url, null);
    }

    /**
     * @param extra fields to add to {@code vellum.data}, from the menu (called on open and every client tick; the
     *              page gets new data when its result changes), or null
     */
    public VellumContainerScreen(M menu, class_1661 inventory, class_2561 title, String url,
                                 @Nullable Function<? super M, ? extends JsonObject> extra) {
        super(menu, inventory, title);
        this.driver = new DocumentDriver(this, url, null, -1);
        this.extra = extra;
        pushSlotData();
        for (class_1735 slot : menu.field_7761) hide(slot); // until the page paints them
    }

    public DocumentDriver driver() {
        return driver;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        setGuiArea(0, 0, field_22789, field_22790); // the whole screen until the page has laid out
        driver.resize(field_22789, field_22790);
    }

    /** The GUI area is where the page's content is, as laid out for this frame (slots are placed relative to it). */
    @Override
    public void beforePaint(Document document) {
        float[] r = Coordinates.contentBounds(document);
        if (r == null) {
            setGuiArea(0, 0, field_22789, field_22790);
            return;
        }
        int x0 = (int) Math.floor(r[0]), y0 = (int) Math.floor(r[1]);
        setGuiArea(x0, y0, (int) Math.ceil(r[0] + r[2]) - x0, (int) Math.ceil(r[1] + r[3]) - y0);
    }

    private void setGuiArea(int left, int top, int width, int height) {
        field_2776 = left;
        field_2800 = top;
        field_2792 = width;
        field_2779 = height;
    }

    //? if >=26 {
    /*@Override
    public void extractRenderState(GuiGraphics g, int mouseX, int mouseY, float a) {
        for (Slot slot : menu.slots) hide(slot); // painting puts back the slots it draws
        driver.extractPage(g, mouseX, mouseY); // the page first, so vanilla's slot layer lands on top of it
        super.extractRenderState(g, mouseX, mouseY, a);
    }

    /^* A hovered slot's item tooltip first; the page's tooltip (an {@code <item tooltip>}'s or a title) where there is none. ^/
    @Override
    protected void extractTooltip(GuiGraphics g, int mouseX, int mouseY) {
        super.extractTooltip(g, mouseX, mouseY);
        if (hoveredSlot == null || !hoveredSlot.hasItem()) driver.extractTooltip(g, mouseX, mouseY);
    }
    *///?} else {
    @Override
    public void method_25394(class_332 g, int mouseX, int mouseY, float a) {
        super.method_25394(g, mouseX, mouseY, a); // the background with the page (renderBg), then slots and the carried stack
        method_2380(g, mouseX, mouseY);
    }

    @Override
    protected void method_2389(class_332 g, float a, int mouseX, int mouseY) {
        for (class_1735 slot : field_2797.field_7761) hide(slot); // painting puts back the slots it draws
        driver.extractPage(g, mouseX, mouseY); // the page first, so vanilla's slots land on top of it
    }

    // A hovered slot's item tooltip first; the page's tooltip (an <item tooltip>'s or a title) where there is none.
    @Override
    protected void method_2380(class_332 g, int mouseX, int mouseY) {
        super.method_2380(g, mouseX, mouseY);
        if (field_2787 == null || !field_2787.method_7681()) driver.extractTooltip(g, mouseX, mouseY);
    }
    //?}

    @Override
    public McCanvas.SlotSink slots() {
        return slotSink;
    }

    /** Vanilla's slot positions are relative to the GUI area. */
    private void placeSlot(int index, int x, int y) {
        if (index >= field_2797.field_7761.size()) return;
        class_1735 slot = field_2797.field_7761.get(index);
        slot.field_7873 = x - field_2776;
        slot.field_7872 = y - field_2800;
    }

    @Override
    protected void method_37432() {
        pushSlotData();
    }

    /** Sends the title, slot contents and extra fields to the page when they changed. */
    private void pushSlotData() {
        JsonObject fields = extraFields();
        boolean changed = !Objects.equals(fields, sentExtra);
        sentExtra = fields;
        if (sent.length != field_2797.field_7761.size()) {
            sent = new class_1799[field_2797.field_7761.size()];
            changed = true;
        }
        for (int i = 0; i < sent.length; i++) {
            class_1799 stack = field_2797.field_7761.get(i).method_7677();
            if (sent[i] == null || !class_1799.method_7973(sent[i], stack)) {
                sent[i] = stack.method_7972();
                changed = true;
            }
        }
        if (!changed) return;
        JsonArray slots = new JsonArray();
        for (class_1799 stack : sent) {
            JsonObject o = new JsonObject();
            o.addProperty("id", stack.method_7960() ? "" : class_7923.field_41178.method_10221(stack.method_7909()).toString());
            o.addProperty("count", stack.method_7947());
            o.addProperty("name", stack.method_7960() ? "" : stack.method_7964().getString());
            slots.add(o);
        }
        JsonObject data = new JsonObject();
        data.addProperty("title", field_22785.getString());
        data.addProperty("inventory", field_29347.getString());
        data.add("slots", slots);
        if (fields != null) fields.entrySet().forEach(e -> data.add(e.getKey(), e.getValue()));
        driver.pushData(data.toString());
    }

    /** A copy of the mod's fields now (it may reuse and change its object), or null; a failing function is logged once. */
    private @Nullable JsonObject extraFields() {
        if (extra == null) return null;
        try {
            JsonObject fields = extra.apply(field_2797);
            return fields == null ? null : fields.deepCopy();
        } catch (RuntimeException e) {
            if (!extraFailed) Constants.LOG.error("Vellum: the data function of {} failed", field_22785.getString(), e);
            extraFailed = true;
            return null;
        }
    }

    /** The page's {@code <title>}, else the menu's title. */
    @Override
    public class_2561 method_25440() {
        return driver.narrator().title(super.method_25440());
    }

    /** The page's focused or hovered element (a slot reads as its item); with none, what vanilla says. */
    @Override
    protected void method_37056(class_6382 output) {
        if (!driver.narrator().addNarratedElement(output)) super.method_37056(output);
    }

    @Override
    public String narration() {
        return PageNarrator.collect(this::method_37062);
    }

    //? if >=26 {
    /*@Override
    protected void extractLabels(GuiGraphics g, int mouseX, int mouseY) {
        // The page draws its own titles.
    }
    *///?} else {
    @Override
    protected void method_2388(class_332 g, int mouseX, int mouseY) {
        // The page draws its own titles.
    }
    //?}

    @Override
    public void method_25432() {
        super.method_25432();
        driver.close();
    }

    @Override
    public void closeDocument() {
        method_25419();
    }

    @Override
    public class_437 screen() {
        return this;
    }

    /** Dropping the carried stack happens outside the page's content: where only html or body is under the pointer. */
    @Override
    protected boolean method_2381(double mouseX, double mouseY, int left, int top/*? if <26 {*/, int button/*?}*/) {
        Element hit = driver.elementAt(mouseX, mouseY);
        return hit != null && DocumentDriver.isBackground(hit);
    }

    private static void hide(class_1735 slot) {
        slot.field_7873 = OFF_SCREEN;
        slot.field_7872 = OFF_SCREEN;
    }

    private @Nullable class_1735 slotAt(double x, double y) {
        for (class_1735 slot : field_2797.field_7761) {
            if (slot.method_7682() && method_2378(slot.field_7873, slot.field_7872, 16, 16, x, y)) return slot;
        }
        return null;
    }

    // ---- Input: slots go to vanilla, everything else to the page ----

    @Override
    public void method_16014(double x, double y) {
        driver.mouseMoved(x, y);
    }

    /**
     * Presses on slots go to vanilla, and so do presses on the page's background while a stack is carried: vanilla drops
     * it ({@link #method_2381}), as outside a vanilla container.
     */
    //? if >=26 {
    /*@Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        boolean vanilla = slotAt(event.x(), event.y()) != null
                || !menu.getCarried().isEmpty() && driver.contentAt(event.x(), event.y()) == null;
        pagePress = !vanilla && driver.mouseClicked(event);
        return pagePress || super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (pagePress) {
            pagePress = false;
            return driver.mouseReleased(event);
        }
        return super.mouseReleased(event);
    }
    *///?} else {
    @Override
    public boolean method_25402(double x, double y, int button) {
        boolean vanilla = slotAt(x, y) != null || !field_2797.method_34255().method_7960() && driver.contentAt(x, y) == null;
        pagePress = !vanilla && driver.mouseClicked(MouseButtonEvent.now(x, y, button));
        return pagePress || super.method_25402(x, y, button);
    }

    @Override
    public boolean method_25406(double x, double y, int button) {
        if (pagePress) {
            pagePress = false;
            return driver.mouseReleased(MouseButtonEvent.now(x, y, button));
        }
        return super.method_25406(x, y, button);
    }
    //?}

    @Override
    public boolean method_25401(double x, double y, double scrollX, double scrollY) {
        return (slotAt(x, y) == null && driver.mouseScrolled(x, y, scrollX, scrollY)) || super.method_25401(x, y, scrollX, scrollY);
    }

    //? if >=26 {
    /*@Override
    public boolean keyPressed(KeyEvent event) {
        return driver.keyPressed(event) || super.keyPressed(event);
    }

    @Override
    public boolean keyReleased(KeyEvent event) {
        return driver.keyReleased(event) || super.keyReleased(event);
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        return driver.charTyped(event);
    }
    *///?} else {
    @Override
    public boolean method_25404(int key, int scancode, int modifiers) {
        return driver.keyPressed(new KeyEvent(key, scancode, modifiers)) || super.method_25404(key, scancode, modifiers);
    }

    @Override
    public boolean method_16803(int key, int scancode, int modifiers) {
        return driver.keyReleased(new KeyEvent(key, scancode, modifiers)) || super.method_16803(key, scancode, modifiers);
    }

    @Override
    public boolean method_25400(char c, int modifiers) {
        return driver.charTyped(new CharacterEvent(c));
    }
    //?}
}
