package dev.vellum.mod.net;

import dev.vellum.mod.Constants;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/** Server → client: new {@code vellum.data} (a JSON value) for an open session. */
public record DataPayload(int session, String data) implements class_8710 {
    public static final class_9154<DataPayload> TYPE = new class_9154<>(Constants.id("data"));

    public static final class_9139<ByteBuf, DataPayload> STREAM_CODEC = class_9139.method_56435(
            class_9135.field_48550, DataPayload::session,
            class_9135.method_56364(OpenPayload.MAX_DATA), DataPayload::data,
            DataPayload::new);

    @Override
    public class_9154<DataPayload> method_56479() {
        return TYPE;
    }
}
