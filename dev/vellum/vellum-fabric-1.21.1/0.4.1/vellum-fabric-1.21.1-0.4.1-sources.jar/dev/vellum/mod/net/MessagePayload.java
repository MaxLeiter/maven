package dev.vellum.mod.net;

import dev.vellum.mod.Constants;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/** Client → server: {@code vellum.send(channel, value)} from a session's page; {@code json} is the value as JSON. */
public record MessagePayload(int session, String channel, String json) implements class_8710 {
    public static final class_9154<MessagePayload> TYPE = new class_9154<>(Constants.id("message"));
    public static final int MAX_CHANNEL = 64;
    /** Serverbound payloads are capped at 32 KiB; messages are small by design. */
    public static final int MAX_JSON = 8192;

    public static final class_9139<ByteBuf, MessagePayload> STREAM_CODEC = class_9139.method_56436(
            class_9135.field_48550, MessagePayload::session,
            class_9135.method_56364(MAX_CHANNEL), MessagePayload::channel,
            class_9135.method_56364(MAX_JSON), MessagePayload::json,
            MessagePayload::new);

    @Override
    public class_9154<MessagePayload> method_56479() {
        return TYPE;
    }
}
