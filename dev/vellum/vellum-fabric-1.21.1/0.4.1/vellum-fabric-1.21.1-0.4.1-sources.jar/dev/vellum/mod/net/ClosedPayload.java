package dev.vellum.mod.net;

import dev.vellum.mod.Constants;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/** Client → server: the player closed a session's screen (or it was replaced by another). */
public record ClosedPayload(int session) implements class_8710 {
    public static final class_9154<ClosedPayload> TYPE = new class_9154<>(Constants.id("closed"));

    public static final class_9139<ByteBuf, ClosedPayload> STREAM_CODEC =
            class_9135.field_48550.method_56432(ClosedPayload::new, ClosedPayload::session);

    @Override
    public class_9154<ClosedPayload> method_56479() {
        return TYPE;
    }
}
