package dev.vellum.mod.client;

import dev.vellum.engine.dom.Document;
import dev.vellum.engine.dom.Element;
import dev.vellum.engine.input.Accessible;
import dev.vellum.engine.input.Narration;
import dev.vellum.mod.Constants;
import org.jspecify.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_333;
import net.minecraft.class_5244;
import net.minecraft.class_6381;
import net.minecraft.class_6382;
import net.minecraft.class_6385;

/**
 * Hands a page's narration ({@link Narration}) to Minecraft's narrator (Ctrl+B), phrased as vanilla phrases its
 * widgets ("Done button. Left click to activate").
 *
 * <p>Screens narrate as vanilla screens do: when one opens, and after input once the pointer rests (750 ms) or a
 * button or key was pressed (200 ms), vanilla's {@code Screen} collects its title ({@link #title}: the page's
 * {@code <title>}) and its widget ({@link #addNarratedElement}: the element the page reads) and says what changed.
 * Every frame a page is drawn while the narrator listens, its live regions' announcements are said, queued or
 * interrupting ({@link #tick}). A HUD overlay over a screen reads the element under the pointer itself, once the
 * pointer has rested there as long as vanilla waits, since the screen under it knows nothing of it.
 */
final class PageNarrator {
    /** How long the pointer rests before an overlay reads what it is on: vanilla's wait after a mouse move. */
    private static final long HOVER_DELAY_MS = 750;
    /** What Vellum handed the narrator since {@link #record} started, or null while no one records. */
    private static @Nullable List<String> recording;

    private final DocumentDriver driver;
    /** The focused element last read (vanilla's last narratable): after it, the hovered element gets its turn. */
    private @Nullable Element lastFocused;
    /** The page's title and the component made of it, so the same title is the same component. */
    private @Nullable String title;
    private @Nullable class_2561 titleComponent;
    /** An overlay's hovered element: what it says, since when the pointer has been on it, and what was last said. */
    private @Nullable String hoverText, hoverSaid;
    private long hoverSince;

    PageNarrator(DocumentDriver driver) {
        this.driver = driver;
    }

    // ---- The screen's narration ----

    /** The screen's title: the page's {@code <title>}, else {@code fallback} (also before the page has loaded). */
    class_2561 title(class_2561 fallback) {
        Document doc = driver.document();
        String text = doc == null ? "" : doc.title();
        if (text.isEmpty()) return fallback;
        if (!text.equals(title)) {
            title = text;
            titleComponent = class_2561.method_43470(text);
        }
        return Objects.requireNonNull(titleComponent);
    }

    /**
     * For {@code Screen.updateNarratedWidget}: adds the element the page reads now as vanilla adds a widget, its place
     * among the page's tab stops and (when focused) the screen's Tab hint, then the element itself one level in. That
     * is the focused element, unless it was the last one read; then the one under the pointer; then the focused one
     * again, as vanilla picks among its widgets. False when the page reads nothing, so the screen says what vanilla
     * says then.
     */
    boolean addNarratedElement(class_6382 output) {
        Document doc = driver.document();
        if (doc == null) return false;
        Narration narration = doc.input().narration();
        Accessible focused = narration.focused(), hovered = narration.hovered();
        Accessible read = focused != null && focused.element() != lastFocused ? focused : hovered != null ? hovered : focused;
        if (read == null) return false;
        boolean focus = focused != null && read.element() == focused.element();
        if (focus) lastFocused = read.element();
        if (read.count() > 1) {
            output.method_37034(class_6381.field_33789,
                    class_2561.method_43469("narrator.position.screen", read.position(), read.count()));
            if (focus) output.method_37034(class_6381.field_33791, class_2561.method_43471("narration.component_list.usage"));
        }
        narrate(read, focus, output.method_37031());
        return true;
    }

    /** What vanilla's narration of a screen says now, all of it, from its {@code updateNarrationState}. */
    static String collect(Consumer<class_6382> updateNarrationState) {
        class_6385 collector = new class_6385();
        //? if >=26 {
        /*collector.update(updateNarrationState, NarrationTrigger.MOUSE);
        *///?} else
        collector.method_37044(updateNarrationState);
        return collector.method_37045(true);
    }

    // ---- Live regions and overlays ----

    /**
     * Every frame the page is drawn, after its frame, while the narrator listens: says what its live regions announce,
     * and with {@code readsPointer} (a HUD overlay over a screen) the element under the pointer once it has rested
     * there for {@link #HOVER_DELAY_MS}.
     */
    void tick(boolean readsPointer) {
        Document doc = driver.document();
        if (doc == null || !listening()) {
            hoverText = hoverSaid = null;
            return;
        }
        Narration narration = doc.input().narration();
        // The first assertive announcement of a frame cuts off what was being said; the rest of the frame queue after
        // it, assertive ones first, so two alerts arriving together are both heard.
        List<Narration.Announcement> announcements = narration.announcements(); // reading takes them
        boolean cut = false;
        for (Narration.Announcement a : announcements) {
            if (!a.interrupt()) continue;
            say(class_2561.method_43470(a.text()), !cut);
            cut = true;
        }
        for (Narration.Announcement a : announcements) {
            if (!a.interrupt()) say(class_2561.method_43470(a.text()), false);
        }
        boolean announced = !announcements.isEmpty();
        Accessible hovered = readsPointer ? narration.hovered() : null;
        // Keys stay with the screen under an overlay, so its elements read as the pointer uses them.
        String text = hovered == null ? null : collect(out -> narrate(hovered, false, out));
        long now = class_156.method_658();
        if (!Objects.equals(text, hoverText)) {
            hoverText = text;
            hoverSince = now;
        }
        if (text == null) hoverSaid = null;
        else if (!text.equals(hoverSaid) && now - hoverSince >= HOVER_DELAY_MS) {
            hoverSaid = text;
            say(class_2561.method_43470(text), !announced); // never cuts off this frame's announcements
        }
    }

    /** Whether anyone listens: the narrator reads system messages, or {@link #record} is on. */
    static boolean listening() {
        if (recording != null) return true;
        class_310 mc = class_310.method_1551();
        return mc.method_44713().method_1791() && mc.field_1690.method_42476().method_41753().method_44716();
    }

    /** Says {@code text}: cutting off what the narrator is saying, or after it. */
    private static void say(class_2561 text, boolean interrupt) {
        String said = text.getString();
        if (said.isEmpty()) return;
        Constants.LOG.debug("Vellum narrates{}: {}", interrupt ? " at once" : "", said);
        if (recording != null) recording.add(said);
        class_333 narrator = class_310.method_1551().method_44713();
        //? if >=26 {
        /*if (interrupt) narrator.saySystemNow(text);
        else narrator.saySystemQueued(text);
        *///?} else {
        if (interrupt) narrator.method_37015(text);
        else narrator.method_47976(text);
        //?}
    }

    /** Starts recording what Vellum hands the narrator, if it was not already, and returns the list it records into. */
    static List<String> record() {
        if (recording == null) recording = new ArrayList<>();
        return recording;
    }

    static void stopRecording() {
        recording = null;
    }

    // ---- Vanilla's phrasing ----

    /** An element as vanilla narrates a widget: its title, how to use it (unless disabled), and its hint. */
    private static void narrate(Accessible a, boolean focused, class_6382 output) {
        int[] tab = a.tabPosition();
        if (tab != null) output.method_37034(class_6381.field_33789, class_2561.method_43469("narrator.position.tab", tab[0], tab[1]));
        output.method_37034(class_6381.field_33788, title(a));
        String usage = a.disabled() ? null : usage(a, focused);
        if (usage != null) output.method_37034(class_6381.field_33791, class_2561.method_43471(usage));
        if (a.hint() != null) output.method_37034(class_6381.field_33790, class_2561.method_43470(a.hint()));
    }

    /**
     * The element's title in vanilla's words where vanilla has them: "Done button", "Volume: 40 slider",
     * "Name edit box: Steve", "Checkbox: Hints: ON", "Item: Iron Sword", "Quests tab"; Vellum's own for links and
     * radios; the name alone for anything else.
     */
    static class_2561 title(Accessible a) {
        class_2561 name = class_2561.method_43470(a.name());
        boolean checked = Boolean.TRUE.equals(a.checked());
        return switch (a.role()) {
            case BUTTON -> class_2561.method_43469("gui.narrate.button", name);
            case COMBOBOX -> class_2561.method_43469("gui.narrate.button", nameValue(name, a.value()));
            case LINK -> class_2561.method_43469("vellum.narrate.link", name);
            case CHECKBOX -> class_2561.method_43469("narration.checkbox", class_5244.method_30619(name, checked));
            case RADIO -> class_2561.method_43469("vellum.narration.radio", class_5244.method_30619(name, checked));
            case SLIDER -> class_2561.method_43469("gui.narrate.slider", nameValue(name, a.value()));
            case TEXTBOX -> class_2561.method_43469("gui.narrate.editBox", name, a.value() == null ? "" : a.value());
            case TAB -> class_2561.method_43469("gui.narrate.tab", name);
            case ITEM, SLOT -> {
                if (a.value() == null) yield name;
                class_2561 item = class_2561.method_43469("narration.item", a.value());
                yield a.name().equals(a.value()) ? item : class_5244.method_37111(name, item);
            }
            case GENERIC, IMG -> name;
        };
    }

    private static class_2561 nameValue(class_2561 name, @Nullable String value) {
        if (value == null || value.isEmpty()) return name;
        return name.getString().isEmpty() ? class_2561.method_43470(value) : class_5244.method_32700(name, class_2561.method_43470(value));
    }

    /**
     * How to use it, as vanilla says for its widgets, for the pointer or the keyboard. Checkboxes toggle with Space
     * and radios move with the arrows in Vellum (Enter does neither, as in HTML), so those say so.
     */
    private static @Nullable String usage(Accessible a, boolean focused) {
        boolean checked = Boolean.TRUE.equals(a.checked());
        return switch (a.role()) {
            case BUTTON, COMBOBOX -> focused ? "narration.button.usage.focused" : "narration.button.usage.hovered";
            case LINK -> focused ? "narration.link.usage.focused" : "narration.link.usage.hovered";
            case CHECKBOX -> focused ? "vellum.narration.checkbox.usage.focused." + (checked ? "uncheck" : "check")
                    : "narration.checkbox.usage.hovered." + (checked ? "uncheck" : "check");
            case RADIO -> focused ? "narration.selection.usage" : checked ? null : "narration.checkbox.usage.hovered.check";
            case SLIDER -> focused ? "narration.slider.usage.focused" : "narration.slider.usage.hovered";
            default -> null;
        };
    }
}
