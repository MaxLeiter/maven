package dev.vellum.mod.client;

import dev.vellum.mod.client.input.CharacterEvent;
import dev.vellum.mod.client.input.KeyEvent;
import dev.vellum.mod.client.input.MouseButtonEvent;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_6382;
import org.jspecify.annotations.Nullable;

/**
 * A screen showing a Vellum page. The page draws its own background over the dimmed world (or the title panorama
 * when no world is loaded); Escape closes the screen unless the page handles it. Open one with {@link VellumScreens}.
 *
 * <p>Its title is the page's {@code <title>} (live, as scripts change {@code document.title}), else "Vellum". The
 * narrator reads it, then the page's focused or hovered element as vanilla reads its widgets ({@link PageNarrator}).
 */
public class VellumScreen extends class_437 implements DocumentDriver.Owner {
    private final DocumentDriver driver;
    private boolean pauses;

    /**
     * @param html    inline HTML, or null to load {@code url}
     * @param session the server session, or -1 for a client-side page
     */
    VellumScreen(String url, @Nullable String html, int session) {
        super(class_2561.method_43471("vellum.screen"));
        this.driver = new DocumentDriver(this, url, html, session);
    }

    /** The page's driver: push data, listen for messages ({@code driver().onMessage(channel, handler)}). */
    public DocumentDriver driver() {
        return driver;
    }

    @Override
    protected void method_25426() {
        driver.resize(field_22789, field_22790);
    }

    //? if >=26 {
    /*@Override
    public void extractRenderState(GuiGraphics g, int mouseX, int mouseY, float a) {
        driver.extract(g, mouseX, mouseY);
    }
    *///?} else {
    @Override
    public void method_25394(class_332 g, int mouseX, int mouseY, float a) {
        // The background as 26.x draws it for this screen: the world dimmed, else the panorama and menu background.
        if (field_22787.field_1687 != null) method_52752(g);
        else method_25420(g, mouseX, mouseY, a);
        driver.extract(g, mouseX, mouseY);
    }
    //?}

    /**
     * Whether this screen pauses a singleplayer world while it is open, like a vanilla book. Off by default, since
     * pages that talk to the server (shops, conversations) need it running. Minecraft asks every tick, so this can
     * change while the screen is open.
     */
    public VellumScreen pauses(boolean pauses) {
        this.pauses = pauses;
        return this;
    }

    /** The page's {@code <title>}, else the screen's own ("Vellum"). */
    @Override
    public class_2561 method_25440() {
        return driver.narrator().title(super.method_25440());
    }

    /** The page's focused or hovered element, phrased as vanilla's widgets; with none, what vanilla says. */
    @Override
    protected void method_37056(class_6382 output) {
        if (!driver.narrator().addNarratedElement(output)) super.method_37056(output);
    }

    @Override
    public String narration() {
        return PageNarrator.collect(this::method_37062);
    }

    @Override
    public boolean method_25421() {
        return pauses;
    }

    //? if >=26 {
    /*@Override
    public boolean isInGameUi() {
        return minecraft.level != null;
    }
    *///?}

    @Override
    public void method_25432() {
        driver.close();
    }

    @Override
    public void closeDocument() {
        method_25419();
    }

    @Override
    public class_437 screen() {
        return this;
    }

    // ---- Input: the page first, then vanilla (Escape closes) ----

    @Override
    public void method_16014(double x, double y) {
        driver.mouseMoved(x, y);
    }

    @Override
    public boolean method_25401(double x, double y, double scrollX, double scrollY) {
        return driver.mouseScrolled(x, y, scrollX, scrollY);
    }

    //? if >=26 {
    /*@Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        return driver.mouseClicked(event);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        return driver.mouseReleased(event);
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        return driver.keyPressed(event) || super.keyPressed(event);
    }

    @Override
    public boolean keyReleased(KeyEvent event) {
        return driver.keyReleased(event);
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        return driver.charTyped(event);
    }
    *///?} else {
    @Override
    public boolean method_25402(double x, double y, int button) {
        return driver.mouseClicked(MouseButtonEvent.now(x, y, button));
    }

    @Override
    public boolean method_25406(double x, double y, int button) {
        return driver.mouseReleased(MouseButtonEvent.now(x, y, button));
    }

    @Override
    public boolean method_25404(int key, int scancode, int modifiers) {
        return driver.keyPressed(new KeyEvent(key, scancode, modifiers)) || super.method_25404(key, scancode, modifiers);
    }

    @Override
    public boolean method_16803(int key, int scancode, int modifiers) {
        return driver.keyReleased(new KeyEvent(key, scancode, modifiers));
    }

    @Override
    public boolean method_25400(char c, int modifiers) {
        return driver.charTyped(new CharacterEvent(c));
    }
    //?}
}
