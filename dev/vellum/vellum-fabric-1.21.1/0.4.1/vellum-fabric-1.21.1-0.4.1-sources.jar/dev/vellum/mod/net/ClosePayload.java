package dev.vellum.mod.net;

import dev.vellum.mod.Constants;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/** Server → client: the server closed a session; the client closes its screen if it still shows it. */
public record ClosePayload(int session) implements class_8710 {
    public static final class_9154<ClosePayload> TYPE = new class_9154<>(Constants.id("close"));

    public static final class_9139<ByteBuf, ClosePayload> STREAM_CODEC =
            class_9135.field_48550.method_56432(ClosePayload::new, ClosePayload::session);

    @Override
    public class_9154<ClosePayload> method_56479() {
        return TYPE;
    }
}
