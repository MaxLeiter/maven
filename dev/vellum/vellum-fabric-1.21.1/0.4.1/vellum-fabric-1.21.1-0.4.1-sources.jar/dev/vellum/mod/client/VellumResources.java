package dev.vellum.mod.client;

import dev.vellum.engine.host.FileStamps;
import dev.vellum.mod.Constants;
import dev.vellum.mod.platform.Services;
import org.jspecify.annotations.Nullable;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2960;
import net.minecraft.class_310;

/**
 * Where pages, stylesheets and scripts come from. A URL {@code ns:path/file.css} is the resource
 * {@code assets/ns/path/file.css}, read through the resource manager (so resource packs can restyle UIs).
 *
 * <p>In a dev environment the source tree ({@code common/src/main/resources/assets}, found from the run directory)
 * is read first, and the source files pages were read from are watched: saving one reloads open documents without a
 * rebuild.
 */
public final class VellumResources {
    private static final long POLL_MS = 200;
    private static @Nullable Path sourceAssets;
    /** Source files read for pages, which the watcher polls. */
    private static final Set<Path> SOURCES_READ = ConcurrentHashMap.newKeySet();

    private VellumResources() {}

    static void init() {
        if (!Services.PLATFORM.isDevelopmentEnvironment()) return;
        sourceAssets = findSourceAssets();
        if (sourceAssets == null) return;
        Constants.LOG.info("Vellum: dev mode, reading UI sources from {} and reloading pages when they are saved", sourceAssets);
        Thread watcher = new Thread(VellumResources::watch, "Vellum source watcher");
        watcher.setDaemon(true);
        watcher.start();
    }

    /** The text of a resource, or null when missing. */
    public static @Nullable String loadText(String url) {
        class_2960 id = class_2960.method_12829(url);
        if (id == null) return null;
        Path source = sourceFile(id);
        try {
            if (source != null) {
                SOURCES_READ.add(source);
                return Files.readString(source, StandardCharsets.UTF_8);
            }
            var resource = class_310.method_1551().method_1478().method_14486(id);
            if (resource.isEmpty()) return null;
            try (InputStream in = resource.get().method_14482()) {
                return new String(in.readAllBytes(), StandardCharsets.UTF_8);
            }
        } catch (IOException e) {
            Constants.LOG.warn("Vellum: cannot read {}: {}", url, e.toString());
            return null;
        }
    }

    private static @Nullable Path sourceFile(class_2960 id) {
        if (sourceAssets == null) return null;
        Path p = sourceAssets.resolve(id.method_12836()).resolve(id.method_12832()).normalize();
        return p.startsWith(sourceAssets) && Files.isRegularFile(p) ? p : null;
    }

    /** Dev runs use {@code <loader>/runs/client} as the working directory; look a few levels up for the sources. */
    private static @Nullable Path findSourceAssets() {
        for (Path dir = Path.of("").toAbsolutePath(); dir != null; dir = dir.getParent()) {
            Path candidate = dir.resolve("common/src/main/resources/assets");
            if (Files.isDirectory(candidate)) return candidate;
        }
        return null;
    }

    private static void watch() {
        FileStamps stamps = new FileStamps();
        while (true) {
            try {
                Thread.sleep(POLL_MS);
            } catch (InterruptedException e) {
                return;
            }
            if (stamps.changed(SOURCES_READ)) class_310.method_1551().execute(DocumentDriver::reloadAll);
        }
    }
}
