package dev.vellum.mod.client.render;

import dev.vellum.engine.host.PixelSurface;
import dev.vellum.mod.Constants;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;

/**
 * A canvas's pixels in game: a {@link class_1011} in a {@link class_1043} registered as
 * {@code vellum:canvas/<n>}, so {@link McCanvas} draws it like any texture. An upload sends only the rows written
 * since the last one, not the whole (up to 2048²) image. Render thread only. (The 1.21.1 one: images hold ABGR.)
 */
public final class McSurface implements PixelSurface {
    private static int nextId;

    private final class_2960 id = Constants.id("canvas/" + nextId++);
    private final class_1011 pixels;
    private final class_1043 texture;
    /** Rows written since the last upload: {@code [dirtyTop, dirtyBottom)}, empty when top >= bottom. */
    private int dirtyTop = Integer.MAX_VALUE, dirtyBottom;

    public McSurface(int width, int height) {
        pixels = new class_1011(width, height, true);
        texture = new class_1043(pixels); // uploads the cleared image
        class_310.method_1551().method_1531().method_4616(id, texture);
    }

    @Override
    public int width() {
        return pixels.method_4307();
    }

    @Override
    public int height() {
        return pixels.method_4323();
    }

    @Override
    public String url() {
        return id.toString();
    }

    @Override
    public void fillRect(int x, int y, int width, int height, int argb) {
        pixels.method_4326(x, y, width, height, swapRedBlue(argb));
        written(y, height);
    }

    @Override
    public void getPixels(int x, int y, int width, int height, int[] argb) {
        for (int row = 0; row < height; row++) {
            for (int i = 0; i < width; i++) argb[row * width + i] = swapRedBlue(pixels.method_4315(x + i, y + row));
        }
    }

    @Override
    public void setPixels(int x, int y, int width, int height, int[] argb) {
        for (int row = 0; row < height; row++) {
            for (int i = 0; i < width; i++) pixels.method_4305(x + i, y + row, swapRedBlue(argb[row * width + i]));
        }
        written(y, height);
    }

    @Override
    public void upload() {
        if (dirtyTop >= dirtyBottom) return;
        texture.method_23207();
        pixels.method_22619(0, 0, dirtyTop, 0, dirtyTop, width(), dirtyBottom - dirtyTop, false, false, false, false);
        dirtyTop = Integer.MAX_VALUE;
        dirtyBottom = 0;
    }

    /** Releases the texture, which frees the image too. */
    @Override
    public void dispose() {
        class_310.method_1551().method_1531().method_4615(id);
    }

    private void written(int y, int height) {
        dirtyTop = Math.min(dirtyTop, y);
        dirtyBottom = Math.max(dirtyBottom, y + height);
    }

    /** ARGB to the image's ABGR and back. */
    private static int swapRedBlue(int color) {
        return color & 0xFF00FF00 | color >> 16 & 0xFF | (color & 0xFF) << 16;
    }
}
