package dev.vellum.mod.client.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_1087;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_2680;
import net.minecraft.class_308;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_898;
import org.joml.Quaternionf;
import org.joml.Quaternionfc;
import org.jspecify.annotations.Nullable;

/**
 * What a 3D picture shows ({@code <entity>}, {@code <model>}): an entity, a block or an item, posed, and drawn around
 * the middle of its box where a block is {@code scale} GUI px. On Minecraft 1.21.1 there are no picture-in-picture
 * renderers: {@link McGui#scene} draws a scene straight into the GUI, clipped to its box, as vanilla's inventory
 * draws the player. The transforms are the 26.x Scene's.
 */
public final class Scene {
    /** How a scene is drawn: {@code pose} has the origin in the middle of the box, y down, a block per unit. */
    @FunctionalInterface
    interface Drawer {
        void draw(class_4587 pose, class_4597 buffers, Box box);
    }

    /** The box on screen, in GUI px, and how many GUI px a block is. */
    record Box(int x0, int y0, int x1, int y1, float scale) {}

    /** The lighting vanilla sets for each kind of GUI model. */
    enum Light { ENTITY, ITEMS_3D, ITEMS_FLAT }

    /** The inventory's view of blocks: 30° from above, turned 225°, 0.625 of a slot. */
    private static final float BLOCK_TILT = 30, BLOCK_YAW = 225, BLOCK_SCALE = 0.625F;

    private final Light light;
    private final Drawer drawer;

    private Scene(Light light, Drawer drawer) {
        this.light = light;
        this.drawer = drawer;
    }

    /**
     * An entity, posed as it is now (the caller sets its fields and puts them back), with its origin {@code dx}
     * blocks right of the middle of the box's bottom edge and {@code up} blocks above it; {@code rotation} turns it,
     * and the camera looks along {@code cameraTilt} (for billboards such as name tags).
     */
    public static Scene entity(class_1297 entity, float partialTick, float dx, float up, Quaternionfc rotation, @Nullable Quaternionfc cameraTilt) {
        return new Scene(Light.ENTITY, (pose, buffers, box) -> {
            // As vanilla's inventory player, with the origin moved from the middle to the bottom edge, then placed.
            pose.method_46416(dx, (box.y1() - box.y0()) / 2F / box.scale() - up, 0);
            pose.method_22907(new Quaternionf(rotation));
            class_898 dispatcher = class_310.method_1551().method_1561();
            if (cameraTilt != null) dispatcher.method_24196(cameraTilt.conjugate(new Quaternionf()).rotateY((float) Math.PI));
            dispatcher.method_3948(false);
            RenderSystem.runAsFancy(() -> dispatcher.method_3954(entity, 0, 0, 0, 0, partialTick, pose, buffers, class_765.field_32767));
            dispatcher.method_3948(true);
        });
    }

    /**
     * A block, as the inventory shows blocks (vanilla's {@code block/block} GUI transform: 30° from above, turned 225°,
     * 0.625 a box), turned by {@code yaw} about its upright axis and seen from {@code pitch} degrees further above, its
     * centre {@code dx} blocks right of the box's middle and {@code dy} below.
     */
    public static Scene block(class_2680 state, float yaw, float pitch, float dx, float dy) {
        return new Scene(Light.ITEMS_3D, (pose, buffers, box) -> {
            pose.method_46416(dx, dy, 0);
            turn(pose, BLOCK_TILT, yaw, pitch);
            pose.method_22907(class_7833.field_40716.rotationDegrees(BLOCK_YAW));
            pose.method_22905(BLOCK_SCALE, BLOCK_SCALE, BLOCK_SCALE);
            pose.method_46416(-0.5F, -0.5F, -0.5F);
            class_310.method_1551().method_1541().method_3353(state, pose, buffers, class_765.field_32767, class_4608.field_21444);
        });
    }

    /**
     * An item in its GUI transform, so at yaw and pitch 0 it is the inventory icon, turned by {@code yaw} about its
     * upright axis and seen from {@code pitch} degrees further above, its centre {@code dx} blocks right of the box's
     * middle and {@code dy} below. Block-like items are tilted 30° toward the viewer in the inventory, flat ones not, so
     * that is the axis they turn about.
     */
    public static Scene item(class_1799 stack, float yaw, float pitch, float dx, float dy) {
        class_310 mc = class_310.method_1551();
        class_1087 model = mc.method_1480().method_4019(stack, mc.field_1687, null, 0);
        boolean blockLike = model.method_24304();
        float tilt = blockLike ? BLOCK_TILT : 0;
        return new Scene(blockLike ? Light.ITEMS_3D : Light.ITEMS_FLAT, (pose, buffers, box) -> {
            pose.method_46416(dx, dy, 0);
            turn(pose, tilt, yaw, pitch);
            pose.method_22907(class_7833.field_40714.rotationDegrees(-tilt)); // the item's GUI transform tilts it again
            mc.method_1480().method_23179(stack, class_811.field_4317, false, pose, buffers, class_765.field_32767,
                    class_4608.field_21444, model);
        });
    }

    /** Faces a GUI model to the viewer, y up, tilted {@code tilt + pitch} degrees from above, turned by yaw. */
    private static void turn(class_4587 pose, float tilt, float yaw, float pitch) {
        pose.method_22905(1, -1, -1); // y up and facing the viewer, as vanilla draws GUI items
        pose.method_22907(class_7833.field_40714.rotationDegrees(tilt + pitch));
        pose.method_22907(class_7833.field_40716.rotationDegrees(-yaw));
    }

    /** Draws the scene with its lighting; {@code pose} is set up for the box ({@link McGui#scene}). */
    void draw(class_4587 pose, class_4597 buffers, Box box) {
        switch (light) {
            case ENTITY -> class_308.method_34742();
            case ITEMS_3D -> class_308.method_24211();
            case ITEMS_FLAT -> class_308.method_24210();
        }
        drawer.draw(pose, buffers, box);
    }
}
