package dev.vellum.fabric;

import dev.vellum.mod.platform.Network;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_3222;
import net.minecraft.class_8710;

public final class FabricNetwork implements Network {
    @Override
    public boolean sendToPlayer(class_3222 player, class_8710 payload) {
        if (!ServerPlayNetworking.canSend(player, payload.method_56479())) return false;
        ServerPlayNetworking.send(player, payload);
        return true;
    }
}
