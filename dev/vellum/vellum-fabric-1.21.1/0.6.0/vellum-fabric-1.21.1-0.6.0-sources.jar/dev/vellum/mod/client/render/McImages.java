package dev.vellum.mod.client.render;

import org.jspecify.annotations.Nullable;

import java.io.IOException;
import java.io.InputStream;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_1058;
import net.minecraft.class_2960;
import net.minecraft.class_310;

/**
 * Minecraft's side of images, cached so painting does no parsing: identifiers for the URLs and sprite ids pages use,
 * the natural size of textures (from the PNG header, without decoding) and of GUI sprites. Each cache is bounded,
 * since scripts can make up URLs. Render thread only; cleared on resource reload.
 */
public final class McImages {
    private static final int CAPACITY = 1024;
    private static final float[] UNKNOWN = new float[0];

    private static final Map<String, class_2960> IDS = lru();
    private static final Map<String, float[]> TEXTURE_SIZES = lru(), SPRITE_SIZES = lru();
    /** Marks a string that is no valid identifier in {@link #IDS}. */
    private static final class_2960 INVALID = class_2960.method_60656("invalid");

    private McImages() {}

    /** The identifier a URL or sprite id names, or null when it is not one. */
    public static @Nullable class_2960 id(String url) {
        class_2960 id = IDS.get(url);
        if (id == null) {
            id = class_2960.method_12829(url);
            IDS.put(url, id == null ? INVALID : id);
        }
        return id == INVALID ? null : id;
    }

    /** {width, height} in px of the texture at {@code url}, or null when unknown. Shared: do not modify. */
    public static float @Nullable [] textureSize(String url) {
        return known(TEXTURE_SIZES.computeIfAbsent(url, McImages::readPngSize));
    }

    /** {width, height} in px of a GUI sprite, or null when there is no such sprite. Shared: do not modify. */
    public static float @Nullable [] spriteSize(String spriteId) {
        return known(SPRITE_SIZES.computeIfAbsent(spriteId, McImages::readSpriteSize));
    }

    /** Resource packs may have replaced images and sprites. */
    public static void clearCaches() {
        TEXTURE_SIZES.clear();
        SPRITE_SIZES.clear();
    }

    private static float @Nullable [] known(float[] size) {
        return size == UNKNOWN ? null : size;
    }

    /** Width and height from the PNG's IHDR chunk. */
    private static float[] readPngSize(String url) {
        class_2960 id = id(url);
        var resource = id == null ? null : class_310.method_1551().method_1478().method_14486(id).orElse(null);
        if (resource == null) return UNKNOWN;
        try (InputStream in = resource.method_14482()) {
            byte[] header = in.readNBytes(24);
            if (header.length < 24 || header[1] != 'P' || header[2] != 'N' || header[3] != 'G') return UNKNOWN;
            return new float[] {readInt(header, 16), readInt(header, 20)};
        } catch (IOException e) {
            return UNKNOWN;
        }
    }

    private static float[] readSpriteSize(String spriteId) {
        class_2960 id = id(spriteId);
        if (id == null) return UNKNOWN;
        //? if >=26 {
        /*TextureAtlasSprite sprite = Minecraft.getInstance().getAtlasManager().getAtlasOrThrow(AtlasIds.GUI).getSprite(id);
        *///?} else
        class_1058 sprite = class_310.method_1551().method_52699().method_18667(id);
        // A missing sprite comes back as the atlas's missing sprite.
        return sprite.method_45851().method_45816().equals(id) ? new float[] {sprite.method_45851().method_45807(), sprite.method_45851().method_45815()} : UNKNOWN;
    }

    private static int readInt(byte[] b, int at) {
        return (b[at] & 0xFF) << 24 | (b[at + 1] & 0xFF) << 16 | (b[at + 2] & 0xFF) << 8 | (b[at + 3] & 0xFF);
    }

    private static <V> Map<String, V> lru() {
        return new LinkedHashMap<>(64, 0.75f, true) {
            @Override
            protected boolean removeEldestEntry(Map.Entry<String, V> eldest) {
                return size() > CAPACITY;
            }
        };
    }
}
