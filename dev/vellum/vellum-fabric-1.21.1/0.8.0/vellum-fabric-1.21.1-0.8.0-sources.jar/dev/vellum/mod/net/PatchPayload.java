package dev.vellum.mod.net;

import dev.vellum.mod.Constants;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Server → client: sets one top-level field of an open session's {@code vellum.data} to {@code value} (a JSON
 * value), or removes it when {@code value} is JSON null.
 */
public record PatchPayload(int session, String key, String value) implements class_8710 {
    public static final class_9154<PatchPayload> TYPE = new class_9154<>(Constants.id("patch"));
    public static final int MAX_KEY = 256;

    public static final class_9139<ByteBuf, PatchPayload> STREAM_CODEC = class_9139.method_56436(
            class_9135.field_48550, PatchPayload::session,
            class_9135.method_56364(MAX_KEY), PatchPayload::key,
            class_9135.method_56364(OpenPayload.MAX_DATA), PatchPayload::value,
            PatchPayload::new);

    @Override
    public class_9154<PatchPayload> method_56479() {
        return TYPE;
    }
}
