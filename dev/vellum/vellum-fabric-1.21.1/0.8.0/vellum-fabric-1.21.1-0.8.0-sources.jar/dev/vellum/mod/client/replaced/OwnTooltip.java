package dev.vellum.mod.client.replaced;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;

/** Replaced content that draws the tooltip it shows ({@code ReplacedContent.showsTooltip}): the Minecraft elements and scenes. */
public interface OwnTooltip {
    /**
     * Shows the content's own tooltip for this frame at GUI point ({@code x}, {@code y}), followed by {@code extra}
     * (the lines of the {@code title} that applies), in one vanilla tooltip. Returns whether it set a tooltip.
     */
    boolean showTooltip(class_332 g, List<class_2561> extra, int x, int y);
}
