package dev.vellum.mod.client.render;

import dev.vellum.mod.Constants;
import dev.vellum.mod.client.VellumResources;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;

/**
 * Images from folder namespaces ({@code VellumPages}), which the texture manager can't load itself: each is read
 * from its file and registered under its own id as a {@link class_1043} the first time a page draws it, and
 * dropped when files change or resources reload. Render thread only.
 */
public final class FolderTextures {
    /** Whether each id read: a missing or unreadable file is remembered too, so it isn't read every frame. */
    private static final Map<class_2960, Boolean> LOADED = new HashMap<>();

    private FolderTextures() {}

    /** Registers the texture for {@code id} if needed; false when its file is missing or isn't a PNG. */
    static boolean ensure(class_2960 id) {
        return LOADED.computeIfAbsent(id, FolderTextures::load);
    }

    private static boolean load(class_2960 id) {
        byte[] bytes = VellumResources.loadFolderBytes(id);
        if (bytes == null) return false;
        try {
            class_1011 image = class_1011.method_4309(new ByteArrayInputStream(bytes));
            //? if >=26 {
            /*DynamicTexture texture = new DynamicTexture(() -> "Vellum " + id, image);
            *///?} else
            class_1043 texture = new class_1043(image);
            class_310.method_1551().method_1531().method_4616(id, texture);
            return true;
        } catch (IOException e) {
            Constants.LOG.warn("Vellum: {} is not a PNG image: {}", id, e.toString());
            return false;
        }
    }

    /** Files changed or resources reloaded: every folder image is read again when next drawn. */
    public static void clear() {
        var textures = class_310.method_1551().method_1531();
        for (var e : LOADED.entrySet()) if (e.getValue()) textures.method_4615(e.getKey());
        LOADED.clear();
    }
}
