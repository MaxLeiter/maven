package dev.vellum.mod.client.showcase;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import dev.vellum.mod.client.DocumentDriver;
import dev.vellum.mod.client.VellumClientCommands;
import dev.vellum.mod.client.VellumScreens;
import org.jspecify.annotations.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1320;
import net.minecraft.class_1826;
import net.minecraft.class_2799;
import net.minecraft.class_310;
import net.minecraft.class_3468;
import net.minecraft.class_3469;
import net.minecraft.class_4048;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_5135;
import net.minecraft.class_634;
import net.minecraft.class_6880;
import net.minecraft.class_746;
import net.minecraft.class_7923;

/**
 * Live data for the Mobdex showcase page ({@code /vellum showcase mobdex}, or its card in the showcase gallery):
 * every living entity type in the registry, vanilla and modded, with its translated name, spawn category, default
 * attributes, size and spawn egg, and the player's kill statistics. The page adds its own flavour text for vanilla
 * mobs.
 *
 * <p>Statistics live on the server; the client's copy is only filled in when asked for, as the vanilla statistics
 * screen does. Loading the page asks, and while a Mobdex is open the statistics are compared every client tick
 * ({@link #tick}) and the pages get the new numbers when they change.
 *
 * <p>The data: {@code {player, mobs: [{id, name, category, hp, atk, def, spd, width, height, egg, killed,
 * killedBy}]}}, merged into what the opener passed (such as {@code start}: {@code {mob, filter, query}}); {@code egg}
 * is the spawn egg's item id or null.
 */
public final class Mobdex {
    public static final String URL = VellumClientCommands.showcaseUrl("mobdex");

    /** The statistics the open pages show ({@link #stats}). */
    private static int[] shown = new int[0];
    /** {@link #types}, listed on first use: the registry and the default attributes are complete by then. */
    private static @Nullable List<class_1299<?>> living;

    private Mobdex() {}

    /** The page is loading in {@code driver} ({@code VellumScreens.onPageLoad}): give it data, ask for statistics. */
    public static void load(DocumentDriver driver) {
        List<class_1299<?>> types = types();
        int[] stats = stats(types);
        driver.merge(data(types, stats));
        shown = stats;
        class_634 connection = class_310.method_1551().method_1562();
        if (connection != null) connection.method_52787(new class_2799(class_2799.class_2800.field_12775));
    }

    /** Client tick: when the statistics changed (they arrived, or the player defeated a mob), open pages show them. */
    public static void tick() {
        List<DocumentDriver> pages = VellumScreens.pages(URL);
        if (pages.isEmpty()) return;
        List<class_1299<?>> types = types();
        int[] stats = stats(types);
        if (Arrays.equals(stats, shown)) return;
        shown = stats;
        JsonObject data = data(types, stats);
        for (DocumentDriver page : pages) page.merge(data);
    }

    /** Living entity types: those with default attributes (both loaders add modded ones there), except the player. */
    private static List<class_1299<?>> types() {
        if (living == null) {
            List<class_1299<?>> types = new ArrayList<>();
            for (class_1299<?> type : class_7923.field_41177) {
                if (type != class_1299.field_6097 && class_5135.method_26875(type)) types.add(type);
            }
            living = List.copyOf(types);
        }
        return living;
    }

    /**
     * Kills and deaths for each type ({@code killed, killedBy} in turn; empty without a player), from the client's
     * copy of the player's statistics.
     */
    private static int[] stats(List<class_1299<?>> types) {
        class_746 player = class_310.method_1551().field_1724;
        if (player == null) return new int[0];
        class_3469 stats = player.method_3143();
        int[] values = new int[types.size() * 2];
        for (int i = 0; i < types.size(); i++) {
            values[2 * i] = stats.method_15024(class_3468.field_15403, types.get(i));
            values[2 * i + 1] = stats.method_15024(class_3468.field_15411, types.get(i));
        }
        return values;
    }

    /** The page's fields, from the registries and {@code stats} ({@link #stats} of {@code types}). */
    private static JsonObject data(List<class_1299<?>> types, int[] stats) {
        class_310 mc = class_310.method_1551();
        Map<class_1299<?>, String> eggs = eggs();
        JsonArray mobs = new JsonArray();
        boolean counted = stats.length > 0;
        for (int i = 0; i < types.size(); i++) {
            class_1299<?> type = types.get(i);
            mobs.add(mob(type, eggs.get(type), counted ? stats[2 * i] : 0, counted ? stats[2 * i + 1] : 0));
        }
        JsonObject data = new JsonObject();
        data.addProperty("player", mc.method_1548().method_1676());
        data.add("mobs", mobs);
        return data;
    }

    /** The spawn egg item id of each entity type that has one (as {@code SpawnEggItem.byId}, in one pass). */
    private static Map<class_1299<?>, String> eggs() {
        Map<class_1299<?>, String> eggs = new HashMap<>();
        //? if >=26 {
        /*for (Holder<Item> item : BuiltInRegistries.ITEM.componentLookup().findAll(DataComponents.ENTITY_DATA)) {
            TypedEntityData<EntityType<?>> data = item.components().get(DataComponents.ENTITY_DATA);
            if (data != null) eggs.putIfAbsent(data.type(), item.getRegisteredName());
        }
        *///?} else {
        for (class_1826 egg : class_1826.method_8017()) {
            eggs.putIfAbsent(egg.method_8015(egg.method_7854()), class_7923.field_41178.method_10221(egg).toString());
        }
        //?}
        return eggs;
    }

    @SuppressWarnings("unchecked")
    private static JsonObject mob(class_1299<?> type, @Nullable String egg, int killed, int killedBy) {
        class_5132 attributes = class_5135.method_26873((class_1299<? extends class_1309>) type);
        class_4048 size = type.method_18386();
        JsonObject mob = new JsonObject();
        mob.addProperty("id", class_7923.field_41177.method_10221(type).toString());
        mob.addProperty("name", type.method_5897().getString());
        mob.addProperty("category", type.method_5891().method_15434());
        mob.addProperty("hp", value(attributes, class_5134.field_23716));
        mob.addProperty("atk", value(attributes, class_5134.field_23721));
        mob.addProperty("def", value(attributes, class_5134.field_23724));
        mob.addProperty("spd", value(attributes, class_5134.field_23719));
        mob.addProperty("width", size.comp_2185());
        mob.addProperty("height", size.comp_2186());
        mob.addProperty("egg", egg);
        mob.addProperty("killed", killed);
        mob.addProperty("killedBy", killedBy);
        return mob;
    }

    /** A default attribute value, rounded for display; 0 when the type does not have it. */
    private static double value(class_5132 attributes, class_6880<class_1320> attribute) {
        return attributes.method_27310(attribute) ? Math.round(attributes.method_26862(attribute) * 1000) / 1000.0 : 0;
    }
}
